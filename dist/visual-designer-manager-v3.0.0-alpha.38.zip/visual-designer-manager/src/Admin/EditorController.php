<?php

declare(strict_types=1);

namespace VisualDesignerManager\Admin;

use VisualDesignerManager\Diagnostics\DiagnosticStore;
use VisualDesignerManager\Frontend\CollectionPageRenderer;
use VisualDesignerManager\Frontend\Renderer;
use VisualDesignerManager\Model\LayoutModel;
use VisualDesignerManager\Model\ModuleDesignModel;
use VisualDesignerManager\Model\TemplateLayoutModel;
use VisualDesignerManager\Update\GitHubUpdater;

final class EditorController
{
    private const MENU = 'vdm-editor';
    private const SAVE_ACTION = 'h18_clean_save';
    private const RESTORE_ACTION = 'h18_clean_restore';
    private const RESTORE_COPY_ACTION = 'h18_clean_restore_copy';
    private const PREVIEW_ACTION = 'h18_clean_preview';
    private const COMPOSITE_PREVIEW_ACTION = 'h18_clean_composite_preview';
    private const VERSION_PREVIEW_ACTION = 'h18_clean_version_preview';
    private const NONCE_SAVE = 'h18_clean_save';
    private const NONCE_RESTORE = 'h18_clean_restore';
    private const NONCE_RESTORE_COPY = 'h18_clean_restore_copy';
    private const NONCE_PREVIEW = 'h18_clean_preview';
    private const NONCE_COMPOSITE_PREVIEW = 'h18_clean_composite_preview';
    private const NONCE_VERSION_PREVIEW = 'h18_clean_version_preview';

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue']);
        add_action('admin_post_' . self::SAVE_ACTION, [self::class, 'save']);
        add_action('admin_post_' . self::RESTORE_ACTION, [self::class, 'restore']);
        add_action('admin_post_' . self::RESTORE_COPY_ACTION, [self::class, 'restoreCopy']);
        add_action('admin_post_' . self::PREVIEW_ACTION, [self::class, 'preview']);
        add_action('admin_post_' . self::COMPOSITE_PREVIEW_ACTION, [self::class, 'compositePreview']);
        add_action('admin_post_' . self::VERSION_PREVIEW_ACTION, [self::class, 'previewVersion']);
        add_filter('show_admin_bar', [self::class, 'hideModulePreviewAdminBar']);
    }

    public static function menu(): void
    {
        add_menu_page(
            'Visual Designer',
            'Visual Designer',
            'edit_pages',
            self::MENU,
            [self::class, 'render'],
            'dashicons-layout',
            21
        );
    }

    public static function enqueue(string $hook): void
    {
        if ($hook !== 'toplevel_page_' . self::MENU || !current_user_can('edit_pages')) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_style('vdm-editor', VDM_URL . 'assets/editor.css', [], VDM_VERSION);
        wp_enqueue_script('vdm-editor', VDM_URL . 'assets/editor.js', ['jquery'], VDM_VERSION, true);
        wp_enqueue_style('h18-vd-module-design-v0177', VDM_URL . 'assets/module-design-v0177.css', [], VDM_VERSION);
        wp_enqueue_script('h18-vd-module-design-v0177', VDM_URL . 'assets/module-design-v0177.js', [], VDM_VERSION, true);

        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        $model = $postId > 0 && get_post_type($postId) === 'page' ? LayoutModel::get($postId) : LayoutModel::empty();
        wp_localize_script('vdm-editor', 'H18CleanEditor', [
            'version' => VDM_VERSION,
            'schemaVersion' => LayoutModel::SCHEMA,
            'units' => LayoutModel::UNITS,
            'rowPx' => LayoutModel::ROW_PX,
            'postId' => $postId,
            'initialModel' => $model,
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'diagAction' => 'h18_clean_diag_append',
            'diagNonce' => wp_create_nonce('h18_clean_diag_append'),
        ]);
    }

    public static function render(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        if ($postId <= 0 || get_post_type($postId) !== 'page') {
            self::renderPagePicker();
            return;
        }

        $post = get_post($postId);
        if (!$post instanceof \WP_Post) {
            self::renderPagePicker();
            return;
        }
        TemplateLayoutModel::ensureMigrated();
        $isCollectionPage = CollectionPageRenderer::supports($postId);
        $collectionMode = $isCollectionPage && sanitize_key((string) ($_GET['h18_collection_mode'] ?? 'content')) === 'module' ? 'module' : 'content';
        $moduleDesign = $isCollectionPage ? ModuleDesignModel::get($postId) : [];
        $moduleDesignDefaults = $isCollectionPage ? ModuleDesignModel::defaults() : [];
        $model = LayoutModel::get($postId);
        $headerTemplates = TemplateLayoutModel::all('header');
        $footerTemplates = TemplateLayoutModel::all('footer');
        $headerChoice = TemplateLayoutModel::pageChoice($postId, 'header');
        $footerChoice = TemplateLayoutModel::pageChoice($postId, 'footer');
        $history = array_reverse(LayoutModel::history($postId));
        $status = isset($_GET['h18_clean_status']) ? sanitize_key((string) wp_unslash($_GET['h18_clean_status'])) : '';
        $message = isset($_GET['h18_clean_message']) ? sanitize_text_field((string) wp_unslash($_GET['h18_clean_message'])) : '';

        echo '<div class="wrap h18-clean-admin">';
        echo '<h1>Visual Designer · ' . esc_html((string) $post->post_title) . '</h1>';
        echo '<p class="description">Visual Designer ' . esc_html(VDM_VERSION) . ' · 120 layout-units · modeldrevet Save/Reload · ingen legacy editor-runtime.</p>';
        if ($message !== '') {
            echo '<div class="notice ' . ($status === 'error' ? 'notice-error' : ($status === 'info' ? 'notice-info' : 'notice-success')) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
        }

        echo '<div class="h18-clean-topbar">';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=' . self::MENU)) . '">← Vælg side</a>';
        echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url(get_permalink($postId)) . '">Vis offentlig side</a>';
        if ($isCollectionPage) { echo '<a class="button ' . ($collectionMode === 'content' ? 'button-primary' : '') . '" href="' . esc_url(add_query_arg(['page'=>self::MENU,'post'=>$postId,'h18_collection_mode'=>'content'], admin_url('admin.php'))) . '">Indholdselementer</a><a class="button ' . ($collectionMode === 'module' ? 'button-primary' : '') . '" href="' . esc_url(add_query_arg(['page'=>self::MENU,'post'=>$postId,'h18_collection_mode'=>'module'], admin_url('admin.php'))) . '">Moduldesign</a>'; }
        echo '<button type="button" class="button" id="h18-clean-copy-diag" data-url="' . esc_attr(DiagnosticStore::supportUrl($postId)) . '">Kopiér diagnose-link</button>';
        echo GitHubUpdater::checkButtonHtml();
        echo '</div>';

        echo '<form id="h18-clean-save-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(self::NONCE_SAVE);
        echo '<input type="hidden" name="action" value="' . esc_attr(self::SAVE_ACTION) . '">';
        echo '<input type="hidden" name="post_id" value="' . esc_attr((string) $postId) . '">';
        echo '<input type="hidden" id="h18-clean-model-json" name="model_json" value="' . esc_attr((string) wp_json_encode($model)) . '">';
        echo '<input type="hidden" id="h18-clean-change-note" name="change_note" value="">';
        echo '<input type="hidden" id="h18-module-design-json" name="module_design_json" value="' . esc_attr((string) wp_json_encode($moduleDesign)) . '">';

        echo '<section class="h18-clean-page-shell"><strong>Header / Footer på denne side</strong><label>Header <select name="header_template_choice">';
        echo '<option value="auto"' . selected($headerChoice, 'auto', false) . '>Automatisk / standard</option><option value="none"' . selected($headerChoice, 'none', false) . '>Ingen Header</option>';
        foreach ($headerTemplates as $template) { if (!empty($template['active'])) { echo '<option value="' . esc_attr((string) $template['id']) . '"' . selected($headerChoice, (string) $template['id'], false) . '>' . esc_html((string) $template['name']) . '</option>'; } }
        echo '</select></label><label>Footer <select name="footer_template_choice">';
        echo '<option value="auto"' . selected($footerChoice, 'auto', false) . '>Automatisk / standard</option><option value="none"' . selected($footerChoice, 'none', false) . '>Ingen Footer</option>';
        foreach ($footerTemplates as $template) { if (!empty($template['active'])) { echo '<option value="' . esc_attr((string) $template['id']) . '"' . selected($footerChoice, (string) $template['id'], false) . '>' . esc_html((string) $template['name']) . '</option>'; } }
        echo '</select></label><span class="description">Header og Footer vælges uafhængigt. Theme-shell er aktiv på Visual Designer-sider; Automatisk bruger den aktive website-standard.</span></section>';

        $pageSettings = isset($model['pageSettings']) && is_array($model['pageSettings']) ? $model['pageSettings'] : [];
        echo '<details class="h18-clean-page-shell h18-vd-page-settings" open><summary><strong>Sideindstillinger · Afstande</strong></summary>';
        echo '<p class="description">Styr den enkelte sides responsive luft. Afstand til Footer ligger efter sidste sideelement og før Footeren – ikke inde i Footeren.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Indstilling</th><th>Desktop</th><th>Laptop</th><th>Tablet</th><th>Mobil</th></tr></thead><tbody>';
        $spacingLabels = ['headerGap' => 'Afstand efter Header', 'sectionGap' => 'Afstand mellem sektioner', 'elementGap' => 'Standard afstand mellem elementer', 'footerGap' => 'Afstand til Footer'];
        foreach ($spacingLabels as $spacingKey => $spacingLabel) {
            echo '<tr><th>' . esc_html($spacingLabel) . '</th>';
            foreach (['desktop' => 32, 'laptop' => 32, 'tablet' => 24, 'mobile' => 24] as $device => $fallback) {
                if ($spacingKey === 'elementGap') { $fallback = in_array($device, ['tablet','mobile'], true) ? 14 : 16; }
                $value = isset($pageSettings[$spacingKey][$device]) ? (int) $pageSettings[$spacingKey][$device] : $fallback;
                echo '<td><label><span class="screen-reader-text">' . esc_html($spacingLabel . ' ' . $device) . '</span><input type="number" min="0" max="200" step="1" value="' . esc_attr((string) $value) . '" data-page-spacing-key="' . esc_attr($spacingKey) . '" data-page-spacing-device="' . esc_attr($device) . '"> px</label></td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></details>';

        echo '<div class="h18-clean-toolbar">';
        $isPublished = (string) $post->post_status === 'publish';
        $statusLabel = $isPublished ? 'Publiceret' : 'Kladde';
        echo '<span class="h18-vd-page-status ' . ($isPublished ? 'is-published' : 'is-draft') . '"><strong>Status:</strong> ' . esc_html($statusLabel) . '</span>';
        if ($isPublished) {
            echo '<button type="submit" class="button h18-vd-status-action" name="post_status_action" value="draft" onclick="return confirm(\'Gør siden til kladde? Den fjernes fra offentlig visning, og aktuelle Designer-ændringer gemmes samtidig.\');">Gem &amp; gør til kladde</button>';
        } elseif (current_user_can('publish_pages')) {
            echo '<button type="submit" class="button button-primary h18-vd-status-action" name="post_status_action" value="publish">Gem &amp; publicér</button>';
        }
        echo '<button type="button" class="button" id="h18-clean-undo" disabled>↶ Fortryd</button>';
        echo '<button type="button" class="button" id="h18-clean-redo" disabled>↷ Gentag</button>';
        echo '<span class="h18-clean-grid-label">120 units · 8 px lodret snap</span>';
        echo '<button type="button" class="button" id="h18-clean-preview" data-url="' . esc_attr(admin_url('admin-post.php')) . '" data-nonce="' . esc_attr(wp_create_nonce(self::NONCE_PREVIEW)) . '" data-post-id="' . esc_attr((string) $postId) . '">Forhåndsvis</button>';
        echo '<button type="button" class="button" id="h18-clean-composite-preview" data-url="' . esc_attr(admin_url('admin-post.php')) . '" data-nonce="' . esc_attr(wp_create_nonce(self::NONCE_COMPOSITE_PREVIEW)) . '" data-post-id="' . esc_attr((string) $postId) . '">Vis med Header + Footer</button>';
        echo '<button type="submit" class="button" name="after_save" value="preview" formtarget="_blank">Gem &amp; vis</button>';
        echo '<button type="submit" class="button button-primary h18-clean-save">Gem som ny version</button>';
        echo '</div>';

        if ($isCollectionPage && $collectionMode === 'module') {
            $moduleSlug = sanitize_title((string) get_post_field('post_name', $postId));
            $moduleAdminPage = $moduleSlug === 'events'
                ? 'vdm-events'
                : ($moduleSlug === 'billedgalleri' ? 'vdm-gallery' : 'vdm-vehicles');
            $moduleLabel = $moduleSlug === 'events'
                ? 'Events'
                : ($moduleSlug === 'billedgalleri' ? 'Billedgalleri' : 'Køretøjer');
            $permalink = get_permalink($postId);
            $previewBaseUrl = is_string($permalink) ? $permalink : '';
            $previewUrl = add_query_arg([
                'h18_vd_module_preview' => '1',
                'h18_vd_module_preview_version' => VDM_VERSION,
                'h18_vd_module_design' => (string) wp_json_encode($moduleDesign),
            ], $previewBaseUrl);

            echo '<div class="h18-vd-module-designer-layout">';
            echo '<aside class="h18-vd-module-design-panel" data-defaults="' . esc_attr((string) wp_json_encode($moduleDesignDefaults)) . '">';
            echo '<h2>Moduldesign</h2><p>Ændringer vises direkte i den samme renderer som den offentlige side. Afstand til Footer gælder både moduloversigten og modulets detaljesider.</p>';
            echo '<div class="h18-vd-module-design-grid">';
            $numberFields = [
                'pageWidth' => ['Sidebredde (%)', 60, 100, 1],
                'columnsDesktop' => ['Kolonner · Desktop', 1, 4, 1],
                'columnsTablet' => ['Kolonner · Tablet', 1, 3, 1],
                'columnsMobile' => ['Kolonner · Mobil', 1, 2, 1],
                'cardGap' => ['Afstand mellem kort (px)', 0, 64, 1],
                'cardMaxWidth' => ['Maks. kortbredde (px · 0=auto)', 0, 900, 10],
                'cardPaddingX' => ['Kort padding vandret (px)', 0, 64, 1],
                'cardPaddingY' => ['Kort padding lodret (px)', 0, 64, 1],
                'cardRadius' => ['Hjørneradius (px)', 0, 40, 1],
                'sectionGap' => ['Afstand mellem sektioner (px)', 12, 100, 1],
                'footerGap' => ['Afstand til Footer (px)', 0, 200, 1],
                'h1Size' => ['H1 størrelse (px)', 24, 72, 1],
                'h2Size' => ['H2 størrelse (px)', 18, 56, 1],
                'h3Size' => ['Korttitel/H3 (px)', 14, 40, 1],
                'bodySize' => ['Brødtekst (px)', 12, 24, 1],
            ];
            foreach ($numberFields as $key => $field) {
                echo '<label>' . esc_html((string) $field[0]) . '<input type="number" min="' . esc_attr((string) $field[1]) . '" max="' . esc_attr((string) $field[2]) . '" step="' . esc_attr((string) $field[3]) . '" value="' . esc_attr((string) ($moduleDesign[$key] ?? '')) . '" data-module-design-key="' . esc_attr($key) . '"></label>';
            }
            echo '<label>Kortbillede format<select data-module-design-key="imageRatio">';
            foreach (['16/9' => '16:9', '3/2' => '3:2', '4/3' => '4:3', '1/1' => '1:1'] as $value => $label) {
                echo '<option value="' . esc_attr($value) . '"' . selected((string) ($moduleDesign['imageRatio'] ?? '16/9'), $value, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select></label>';
            echo '<label>Kortbaggrund<input type="color" value="' . esc_attr((string) ($moduleDesign['cardBackground'] ?? '#eee8dc')) . '" data-module-design-key="cardBackground"></label>';
            echo '<label>Tekstfarve<input type="color" value="' . esc_attr((string) ($moduleDesign['cardTextColor'] ?? '#30382a')) . '" data-module-design-key="cardTextColor"></label>';
            echo '<label>Accent/linkfarve<input type="color" value="' . esc_attr((string) ($moduleDesign['accentColor'] ?? '#536243')) . '" data-module-design-key="accentColor"></label>';
            echo '</div>';
            echo '<div class="h18-vd-module-design-actions"><button type="button" class="button" data-module-design-reset>Nulstil til _old-standard</button></div>';
            echo '<p class="h18-vd-module-design-help">Gem som ny version gemmer også Moduldesign. Versions-restore gendanner designet sammen med siden.</p>';
            echo '</aside>';

            echo '<section class="h18-vd-module-canonical-preview">';
            echo '<div class="h18-vd-module-canonical-preview-head"><div><strong>Canonical modul-preview · ' . esc_html($moduleLabel) . '</strong><p>Preview og frontend bruger samme CollectionPageRenderer. Moduldata redigeres fortsat i Manageren.</p></div><div class="h18-vd-module-canonical-preview-actions"><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=' . $moduleAdminPage)) . '">Redigér ' . esc_html($moduleLabel) . '</a><a class="button" target="_blank" rel="noopener" href="' . esc_url($previewBaseUrl) . '">Åbn offentlig side</a></div></div>';
            echo '<iframe class="h18-vd-module-canonical-frame" title="Canonical frontend-preview" data-base-url="' . esc_attr($previewBaseUrl) . '" src="' . esc_url($previewUrl) . '" loading="eager"></iframe>';
            echo '</section></div>';
        } else {
        echo '<div class="h18-clean-workspace">';
        echo '<aside class="h18-clean-palette"><h2>Elementer</h2>';
        $paletteGroups = [
            'Basic' => [
                'section' => 'Sektion', 'container' => 'Kasse', 'text' => 'Tekst', 'image' => 'Billede',
                'button' => 'Knap', 'link' => 'Link', 'spacer' => 'Mellemrum', 'divider' => 'Skillelinje',
                'icon' => 'Ikon', 'badge' => 'Badge', 'datalist' => 'Data List', 'table' => 'Tabel',
            ],
            'Moduler' => [
                'vehiclelist' => 'Køretøjsliste', 'vehicledetail' => 'Køretøjsdetalje',
                'eventlist' => 'Eventliste', 'eventvalue' => 'Eventværdi', 'eventimage' => 'Eventbillede', 'eventfacts' => 'Eventfaktabånd',
                'gallerylist' => 'Gallerioversigt', 'gallerydetail' => 'Albumvisning', 'eventfield' => 'Eventfelt',
            ],
            'Formularer' => [
                'contactform' => 'Kontaktformular', 'membershipform' => 'Bliv medlem-formular',
            ],
        ];
        foreach ($paletteGroups as $groupLabel => $elements) {
            echo '<details class="h18-vd-palette-group" open><summary>' . esc_html($groupLabel) . '</summary><div class="h18-vd-palette-group-items">';
            foreach ($elements as $type => $label) {
                echo '<button type="button" draggable="true" class="button h18-clean-add" data-type="' . esc_attr($type) . '">+ ' . esc_html($label) . '</button>';
            }
            echo '</div></details>';
        }
        echo '<p class="description">Klik tilføjer på root. Træk et palette-element direkte til root, Sektion eller Kasse. Eksisterende elementer flyttes med ✥.</p></aside>';

        echo '<main class="h18-clean-canvas-column">';
        echo '<div id="h18-clean-canvas" class="h18-clean-surface h18-clean-root" data-parent-id=""></div>';
        echo '</main>';

        echo '<aside class="h18-clean-inspector"><h2>Inspector</h2><div id="h18-clean-inspector"><p class="description">Vælg et element på canvas.</p></div></aside>';
        echo '</div>';
        }
        echo '</form>';

        echo '<section class="h18-clean-history"><h2>Gemte versioner</h2>';
        if (!$history) {
            echo '<p>Ingen gemte Visual Designer-versioner endnu.</p>';
        } else {
            echo '<p class="description">Hver Gem opretter en ny version. Gendan på original opretter også en ny version, så historikken aldrig overskrives.</p>';
            echo '<table class="widefat striped"><thead><tr><th>Version</th><th>Gemt</th><th>Note</th><th>Digest</th><th>Handlinger</th></tr></thead><tbody>';
            foreach (array_slice($history, 0, 20) as $entry) {
                $version = (int) ($entry['version'] ?? 0);
                echo '<tr><td><strong>v' . esc_html((string) $version) . '</strong></td>';
                echo '<td>' . esc_html((string) ($entry['savedUtc'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string) ($entry['note'] ?? '')) . '</td>';
                echo '<td><code>' . esc_html(substr((string) ($entry['digest'] ?? ''), 0, 14)) . '…</code></td><td><div class="h18-clean-version-actions">';
                echo '<form method="post" target="_blank" action="' . esc_url(admin_url('admin-post.php')) . '">';
                wp_nonce_field(self::NONCE_VERSION_PREVIEW);
                echo '<input type="hidden" name="action" value="' . esc_attr(self::VERSION_PREVIEW_ACTION) . '"><input type="hidden" name="post_id" value="' . esc_attr((string) $postId) . '"><input type="hidden" name="version" value="' . esc_attr((string) $version) . '">';
                echo '<button class="button" type="submit">Forhåndsvis</button></form>';
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                wp_nonce_field(self::NONCE_RESTORE);
                echo '<input type="hidden" name="action" value="' . esc_attr(self::RESTORE_ACTION) . '"><input type="hidden" name="post_id" value="' . esc_attr((string) $postId) . '"><input type="hidden" name="version" value="' . esc_attr((string) $version) . '">';
                echo '<button class="button" type="submit" onclick="return confirm(\'Gendan v' . esc_js((string) $version) . ' på original-siden? Den nuværende version bevares i historikken.\');">Gendan original</button></form>';
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                wp_nonce_field(self::NONCE_RESTORE_COPY);
                echo '<input type="hidden" name="action" value="' . esc_attr(self::RESTORE_COPY_ACTION) . '"><input type="hidden" name="post_id" value="' . esc_attr((string) $postId) . '"><input type="hidden" name="version" value="' . esc_attr((string) $version) . '">';
                echo '<button class="button" type="submit" onclick="return confirm(\'Opret en ny kladde som kopi af v' . esc_js((string) $version) . '? Original-siden ændres ikke.\');">Opret kopi</button></form>';
                echo '</div></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</section></div>';
    }

    public static function save(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_SAVE);
        $postId = absint($_POST['post_id'] ?? 0);
        if ($postId <= 0 || get_post_type($postId) !== 'page') {
            self::redirect($postId, 'error', 'Ugyldig side.');
        }
        $rawJson = isset($_POST['model_json']) ? (string) wp_unslash($_POST['model_json']) : '';
        if ($rawJson === '' || strlen($rawJson) > 2 * 1024 * 1024) {
            self::redirect($postId, 'error', 'Layoutmodellen mangler eller er for stor.');
        }
        $decoded = json_decode($rawJson, true);
        if (!is_array($decoded)) {
            self::redirect($postId, 'error', 'Layoutmodellen er ikke gyldig JSON.');
        }

        try {
            $normalized = LayoutModel::normalize($decoded);
            DiagnosticStore::append($postId, 'save_begin', [
                'currentVersion' => (int) get_post_meta($postId, LayoutModel::VERSION_META, true),
                'incoming' => DiagnosticStore::modelSummary($normalized),
            ]);
            $note = isset($_POST['change_note']) ? sanitize_text_field((string) wp_unslash($_POST['change_note'])) : '';
            TemplateLayoutModel::ensureMigrated();
            $headerChoice = sanitize_key((string) wp_unslash($_POST['header_template_choice'] ?? 'auto'));
            $footerChoice = sanitize_key((string) wp_unslash($_POST['footer_template_choice'] ?? 'auto'));
            $currentVersion = max(0, (int) get_post_meta($postId, LayoutModel::VERSION_META, true));
            $sameModel = hash_equals(LayoutModel::structuralDigest(LayoutModel::get($postId)), LayoutModel::structuralDigest($normalized));
            $sameShell = TemplateLayoutModel::pageChoice($postId, 'header') === ($headerChoice !== '' ? $headerChoice : 'auto')
                && TemplateLayoutModel::pageChoice($postId, 'footer') === ($footerChoice !== '' ? $footerChoice : 'auto');
            $isCollectionPage = CollectionPageRenderer::supports($postId);
            $moduleDesign = $isCollectionPage ? ModuleDesignModel::get($postId) : [];
            $sameModuleDesign = true;
            if ($isCollectionPage) {
                $moduleDesignJson = isset($_POST['module_design_json']) ? (string) wp_unslash($_POST['module_design_json']) : '';
                $moduleDesignRaw = json_decode($moduleDesignJson, true);
                if (!is_array($moduleDesignRaw)) {
                    throw new \RuntimeException('Moduldesign mangler eller er ugyldigt.');
                }
                $moduleDesign = ModuleDesignModel::normalize($moduleDesignRaw);
                $sameModuleDesign = hash_equals(ModuleDesignModel::digest(ModuleDesignModel::get($postId)), ModuleDesignModel::digest($moduleDesign));
            }
            $statusAction = sanitize_key((string) wp_unslash($_POST['post_status_action'] ?? ''));
            $desiredStatus = in_array($statusAction, ['publish', 'draft'], true) ? $statusAction : '';
            $currentPostStatus = (string) get_post_status($postId);
            $statusChanged = $desiredStatus !== '' && $desiredStatus !== $currentPostStatus;
            if ($desiredStatus === 'publish' && !current_user_can('publish_pages')) {
                throw new \RuntimeException('Du har ikke rettighed til at publicere sider.');
            }
            if ($currentVersion > 0 && $sameModel && $sameShell && $sameModuleDesign && !$statusChanged) {
                // A previous Designer save may already be canonical while a page cache still
                // contains older frontend HTML. Touching the page is therefore intentional
                // even on a canonical no-op save.
                self::touchFrontendPage($postId, '', $currentVersion);
                DiagnosticStore::append($postId, 'save_noop', ['version' => $currentVersion, 'reason' => 'canonical-model-and-shell-unchanged; module-design-unchanged']);
                self::redirect($postId, 'info', 'Ingen ændringer at gemme.');
            }
            if ($currentVersion > 0 && $sameModel && $sameShell && $sameModuleDesign) {
                $version = $currentVersion;
            } else {
                $version = LayoutModel::saveVersion($postId, $normalized, get_current_user_id(), $note !== '' ? $note : ($isCollectionPage ? 'Gemt Moduldesign' : 'Gemt Visual Designer-layout'));
                TemplateLayoutModel::setPageChoice($postId, 'header', $headerChoice);
                TemplateLayoutModel::setPageChoice($postId, 'footer', $footerChoice);
                if ($isCollectionPage) {
                    ModuleDesignModel::save($postId, $moduleDesign, $version);
                }
            }
            // LayoutModel::saveVersion() writes canonical Designer data to post meta.
            // Touch the WordPress page only AFTER those writes so conventional WordPress,
            // host and plugin caches observe and purge against the new Designer state.
            self::touchFrontendPage($postId, $statusChanged ? $desiredStatus : '', $version);
            if ($statusChanged) {
                DiagnosticStore::append($postId, 'page_status_changed', ['from' => $currentPostStatus, 'to' => $desiredStatus, 'version' => $version]);
            }
            $saved = LayoutModel::get($postId);
            $incomingDigest = LayoutModel::structuralDigest($normalized);
            $savedDigest = LayoutModel::structuralDigest($saved);
            if (!hash_equals($incomingDigest, $savedDigest)) {
                throw new \RuntimeException('Save-verifikation fejlede: den gemte canonical model matcher ikke den indsendte model.');
            }
            DiagnosticStore::append($postId, 'save_result', [
                'version' => $version,
                'digest' => $savedDigest,
                'saved' => DiagnosticStore::modelSummary($saved),
            ]);
            if (isset($_POST['after_save']) && sanitize_key((string) wp_unslash($_POST['after_save'])) === 'preview') {
                $permalink = get_permalink($postId);
                if (is_string($permalink) && $permalink !== '') {
                    // The version query makes Gem & vis unambiguous even behind a cache layer
                    // that does not immediately honour a WordPress purge event.
                    wp_safe_redirect(add_query_arg('h18_vd_saved', $version, $permalink));
                    exit;
                }
            }
            $statusMessage = $statusChanged ? ($desiredStatus === 'publish' ? ' Siden er publiceret.' : ' Siden er nu kladde og ikke længere offentligt publiceret.') : '';
            self::redirect($postId, 'success', 'Siden er gemt. Version v' . $version . ' er oprettet.' . $statusMessage);
        } catch (\Throwable $error) {
            DiagnosticStore::append($postId, 'save_error', ['errorType' => get_class($error), 'message' => $error->getMessage()]);
            self::redirect($postId, 'error', 'Siden kunne ikke gemmes: ' . $error->getMessage());
        }
    }

    public static function compositePreview(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_COMPOSITE_PREVIEW);
        $postId = absint($_POST['post_id'] ?? 0);
        if ($postId <= 0 || get_post_type($postId) !== 'page') {
            wp_die(esc_html__('Ugyldig side.', 'visual-designer-manager'));
        }
        $decoded = json_decode(isset($_POST['model_json']) ? (string) wp_unslash($_POST['model_json']) : '', true);
        if (!is_array($decoded)) {
            wp_die(esc_html__('Preview-modellen er ikke gyldig JSON.', 'visual-designer-manager'));
        }
        try {
            $pageModel = LayoutModel::normalize($decoded);
            TemplateLayoutModel::ensureMigrated();
            $headerChoice = sanitize_key((string) wp_unslash($_POST['header_template_choice'] ?? 'auto'));
            $footerChoice = sanitize_key((string) wp_unslash($_POST['footer_template_choice'] ?? 'auto'));
            $headerModel = self::templateModelForPreview('header', $headerChoice);
            $footerModel = self::templateModelForPreview('footer', $footerChoice);
            $previewDevice = sanitize_key((string) wp_unslash($_POST['preview_device'] ?? 'desktop'));
            $previewWidths = ['desktop' => 1920, 'laptop' => 1100, 'tablet' => 850, 'mobile' => 390];
            if (!isset($previewWidths[$previewDevice])) { $previewDevice = 'desktop'; }
            $previewLabel = ['desktop' => 'Desktop', 'laptop' => 'Laptop', 'tablet' => 'Tablet', 'mobile' => 'Mobil'][$previewDevice];
            nocache_headers();
            header('Content-Type: text/html; charset=utf-8');
            echo Renderer::standaloneDocument($pageModel, $headerModel, $footerModel, 'Visual Designer · Header + Footer · ' . $previewLabel . ' · ' . $previewWidths[$previewDevice] . ' px');
            exit;
        } catch (\Throwable $error) {
            wp_die(esc_html('Samlet preview fejlede: ' . $error->getMessage()));
        }
    }

    private static function devicePreviewDocument(string $url, string $device, int $width): string
    {
        $labels = ['desktop' => 'Desktop', 'laptop' => 'Laptop', 'tablet' => 'Tablet', 'mobile' => 'Mobil'];
        $label = $labels[$device] ?? ucfirst($device);
        $safeUrl = esc_url($url);
        $safeTitle = esc_html('Visual Designer · ' . $label . ' · ' . $width . ' px');
        $deviceJson = (string) wp_json_encode($device);
        $labelJson = (string) wp_json_encode($label);
        $urlJson = (string) wp_json_encode($safeUrl);
        return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . $safeTitle . '</title>'
            . '<style>html,body{margin:0;height:100%;overflow:hidden;background:#dcdcde;color:#1d2327;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.h18-vd-device-bar{height:52px;box-sizing:border-box;display:flex;align-items:center;gap:10px;padding:8px 14px;background:#fff;border-bottom:1px solid #c3c4c7}.h18-vd-device-bar strong{margin-right:auto}.h18-vd-device-bar button{min-height:34px;padding:0 12px;border:1px solid #2271b1;border-radius:4px;background:#fff;color:#135e96;cursor:pointer}.h18-vd-device-view{height:calc(100vh - 52px);overflow:auto;padding:16px;box-sizing:border-box}.h18-vd-device-stage{margin:0 auto;transform-origin:top center}.h18-vd-device-frame{display:block;border:0;background:#fff;box-shadow:0 3px 18px rgba(0,0,0,.18);transform-origin:top left}</style></head><body>'
            . '<div class="h18-vd-device-bar"><strong id="h18-vd-device-label"></strong><span id="h18-vd-device-scale"></span><button type="button" id="h18-vd-fit">Tilpas</button><button type="button" id="h18-vd-100">100%</button></div>'
            . '<div class="h18-vd-device-view" id="h18-vd-device-view"><div class="h18-vd-device-stage" id="h18-vd-device-stage"><iframe class="h18-vd-device-frame" id="h18-vd-device-frame" title="' . esc_attr($label) . ' preview" src="' . $safeUrl . '"></iframe></div></div>'
            . '<script>(function(){var WIDTH=' . $width . ',device=' . $deviceJson . ',label=' . $labelJson . ',url=' . $urlJson . ';var fitMode=true;var frame=document.getElementById("h18-vd-device-frame"),stage=document.getElementById("h18-vd-device-stage"),view=document.getElementById("h18-vd-device-view"),scaleText=document.getElementById("h18-vd-device-scale"),labelEl=document.getElementById("h18-vd-device-label");if(labelEl)labelEl.textContent=label+" · "+WIDTH+" px";function apply(scale){scale=Math.max(.15,Math.min(1,scale));frame.style.width=WIDTH+"px";var visible=Math.max(420,view.clientHeight-4);frame.style.height=Math.max(600,Math.floor(visible/scale))+"px";frame.style.transform="scale("+scale+")";stage.style.width=Math.ceil(WIDTH*scale)+"px";stage.style.height=visible+"px";if(scaleText)scaleText.textContent=Math.round(scale*100)+"%";}function fit(){var available=Math.max(180,view.clientWidth-8);apply(Math.min(1,available/WIDTH));}document.getElementById("h18-vd-fit").addEventListener("click",function(){fitMode=true;fit();});document.getElementById("h18-vd-100").addEventListener("click",function(){fitMode=false;apply(1);});window.addEventListener("resize",function(){if(fitMode)fit();});fit();})();</script></body></html>';
    }

    public static function preview(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_PREVIEW);
        $postId = absint($_POST['post_id'] ?? 0);
        if ($postId <= 0 || get_post_type($postId) !== 'page') {
            wp_die(esc_html__('Ugyldig side.', 'visual-designer-manager'));
        }
        $rawJson = isset($_POST['model_json']) ? (string) wp_unslash($_POST['model_json']) : '';
        if ($rawJson === '' || strlen($rawJson) > 2 * 1024 * 1024) {
            wp_die(esc_html__('Preview-modellen mangler eller er for stor.', 'visual-designer-manager'));
        }
        $decoded = json_decode($rawJson, true);
        if (!is_array($decoded)) {
            wp_die(esc_html__('Preview-modellen er ikke gyldig JSON.', 'visual-designer-manager'));
        }
        try {
            $normalized = LayoutModel::normalize($decoded);
            $token = strtolower(wp_generate_password(24, false, false));
            set_transient(Renderer::previewKey(get_current_user_id(), $postId, $token), $normalized, 10 * MINUTE_IN_SECONDS);
            DiagnosticStore::append($postId, 'preview_open', [
                'digest' => LayoutModel::structuralDigest($normalized),
                'state' => DiagnosticStore::modelSummary($normalized),
            ]);
            $permalink = get_permalink($postId);
            if (!is_string($permalink) || $permalink === '') {
                throw new \RuntimeException('Siden har ingen gyldig permalink.');
            }
            $previewUrl = add_query_arg('h18_clean_preview', rawurlencode($token), $permalink);
            $previewDevice = sanitize_key((string) wp_unslash($_POST['preview_device'] ?? ''));
            $previewWidths = ['desktop' => 1920, 'laptop' => 1100, 'tablet' => 850, 'mobile' => 390];
            if (isset($previewWidths[$previewDevice])) {
                nocache_headers();
                header('Content-Type: text/html; charset=utf-8');
                echo self::devicePreviewDocument($previewUrl, $previewDevice, (int) $previewWidths[$previewDevice]);
                exit;
            }
            wp_safe_redirect($previewUrl);
            exit;
        } catch (\Throwable $error) {
            DiagnosticStore::append($postId, 'preview_error', ['errorType' => get_class($error), 'message' => $error->getMessage()]);
            wp_die(esc_html('Forhåndsvisning fejlede: ' . $error->getMessage()));
        }
    }

    public static function previewVersion(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_VERSION_PREVIEW);
        $postId = absint($_POST['post_id'] ?? 0);
        $targetVersion = absint($_POST['version'] ?? 0);
        if ($postId <= 0 || get_post_type($postId) !== 'page' || $targetVersion <= 0) {
            wp_die(esc_html__('Ugyldig versionsanmodning.', 'visual-designer-manager'));
        }
        $target = LayoutModel::historyModel($postId, $targetVersion);
        if ($target === null) {
            wp_die(esc_html__('Den valgte Visual Designer-version findes ikke længere.', 'visual-designer-manager'));
        }
        $token = strtolower(wp_generate_password(24, false, false));
        set_transient(Renderer::previewKey(get_current_user_id(), $postId, $token), $target, 10 * MINUTE_IN_SECONDS);
        DiagnosticStore::append($postId, 'version_preview_open', ['targetVersion' => $targetVersion]);
        $permalink = get_permalink($postId);
        if (!is_string($permalink) || $permalink === '') {
            wp_die(esc_html__('Siden har ingen gyldig permalink.', 'visual-designer-manager'));
        }
        wp_safe_redirect(add_query_arg([
            'h18_clean_preview' => rawurlencode($token),
            'h18_clean_preview_version' => $targetVersion,
        ], $permalink));
        exit;
    }

    public static function restoreCopy(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_RESTORE_COPY);
        $postId = absint($_POST['post_id'] ?? 0);
        $targetVersion = absint($_POST['version'] ?? 0);
        $source = get_post($postId);
        if (!$source instanceof \WP_Post || $source->post_type !== 'page' || $targetVersion <= 0) {
            self::redirect($postId, 'error', 'Ugyldig kopi-anmodning.');
        }
        try {
            $target = LayoutModel::historyModel($postId, $targetVersion);
            if ($target === null) {
                throw new \RuntimeException('Den valgte Visual Designer-version findes ikke længere i historikken.');
            }
            $copyId = wp_insert_post([
                'post_type' => 'page',
                'post_status' => 'draft',
                'post_title' => (string) $source->post_title . ' – kopi fra v' . $targetVersion,
                'post_content' => (string) $source->post_content,
                'post_excerpt' => (string) $source->post_excerpt,
                'post_parent' => (int) $source->post_parent,
                'menu_order' => (int) $source->menu_order,
                'post_author' => get_current_user_id(),
            ], true);
            if (is_wp_error($copyId)) {
                throw new \RuntimeException($copyId->get_error_message());
            }
            $copyId = (int) $copyId;
            $template = get_page_template_slug($postId);
            if (is_string($template) && $template !== '') {
                update_post_meta($copyId, '_wp_page_template', $template);
            }
            $thumb = get_post_thumbnail_id($postId);
            if ($thumb > 0) {
                set_post_thumbnail($copyId, $thumb);
            }
            $copyVersion = LayoutModel::saveVersion($copyId, $target, get_current_user_id(), 'Kopi fra side ' . $postId . ' · v' . $targetVersion);
            $copyDesign = ModuleDesignModel::historyDesign($postId, $targetVersion);
            if ($copyDesign !== null) { ModuleDesignModel::save($copyId, $copyDesign, $copyVersion); }
            DiagnosticStore::append($postId, 'restore_copy_result', ['targetVersion' => $targetVersion, 'copyPostId' => $copyId, 'copyVersion' => $copyVersion]);
            self::redirect($copyId, 'success', 'Kopi oprettet som kladde fra v' . $targetVersion . '. Kopien starter sin egen historik ved v' . $copyVersion . '.');
        } catch (\Throwable $error) {
            DiagnosticStore::append($postId, 'restore_copy_error', ['targetVersion' => $targetVersion, 'errorType' => get_class($error), 'message' => $error->getMessage()]);
            self::redirect($postId, 'error', 'Kopi fejlede: ' . $error->getMessage());
        }
    }

    public static function restore(): void
    {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Ingen adgang.', 'visual-designer-manager'));
        }
        check_admin_referer(self::NONCE_RESTORE);
        $postId = absint($_POST['post_id'] ?? 0);
        $targetVersion = absint($_POST['version'] ?? 0);
        if ($postId <= 0 || get_post_type($postId) !== 'page' || $targetVersion <= 0) {
            self::redirect($postId, 'error', 'Ugyldig restore-anmodning.');
        }

        try {
            $target = LayoutModel::historyModel($postId, $targetVersion);
            if ($target === null) {
                throw new \RuntimeException('Den valgte Visual Designer-version findes ikke længere i historikken.');
            }
            $before = LayoutModel::get($postId);
            DiagnosticStore::append($postId, 'restore_begin', [
                'targetVersion' => $targetVersion,
                'before' => DiagnosticStore::modelSummary($before),
                'target' => DiagnosticStore::modelSummary($target),
            ]);
            $newVersion = LayoutModel::saveVersion(
                $postId,
                $target,
                get_current_user_id(),
                'Restore fra v' . $targetVersion
            );
            $restoredDesign = ModuleDesignModel::historyDesign($postId, $targetVersion);
            if ($restoredDesign !== null) { ModuleDesignModel::save($postId, $restoredDesign, $newVersion); }
            self::touchFrontendPage($postId, '', $newVersion);
            DiagnosticStore::append($postId, 'restore_result', [
                'targetVersion' => $targetVersion,
                'newVersion' => $newVersion,
                'saved' => DiagnosticStore::modelSummary(LayoutModel::get($postId)),
            ]);
            self::redirect($postId, 'success', 'Version v' . $targetVersion . ' restored som ny version v' . $newVersion . '.');
        } catch (\Throwable $error) {
            DiagnosticStore::append($postId, 'restore_error', ['targetVersion' => $targetVersion, 'errorType' => get_class($error), 'message' => $error->getMessage()]);
            self::redirect($postId, 'error', 'Restore fejlede: ' . $error->getMessage());
        }
    }

    private static function renderPagePicker(): void
    {
        $pages = get_pages(['sort_column' => 'post_title', 'sort_order' => 'ASC', 'post_status' => ['publish', 'draft', 'pending', 'private', 'future']]);
        echo '<div class="wrap"><h1>Visual Designer</h1><p>Vælg en WordPress-side. Der importeres intet gammelt editor-state automatisk.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Side</th><th>Slug</th><th>WordPress-status</th><th>Designer-version</th><th></th></tr></thead><tbody>';
        foreach ($pages as $page) {
            if (!$page instanceof \WP_Post) {
                continue;
            }
            $version = (int) get_post_meta($page->ID, LayoutModel::VERSION_META, true);
            $statusObject = get_post_status_object((string) $page->post_status);
            $statusLabel = $statusObject ? (string) $statusObject->label : (string) $page->post_status;
            echo '<tr><td>' . esc_html((string) $page->post_title) . '</td><td><code>' . esc_html((string) $page->post_name) . '</code></td><td>' . esc_html($statusLabel) . '</td><td>' . esc_html($version > 0 ? 'v' . $version : 'Ikke gemt endnu') . '</td><td><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=' . self::MENU . '&post=' . $page->ID)) . '">Åbn designer</a></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    /** @return array<string,mixed>|null */
    private static function templateModelForPreview(string $part, string $choice): ?array
    {
        $part = sanitize_key($part) === 'footer' ? 'footer' : 'header';
        $choice = sanitize_key($choice);
        $id = TemplateLayoutModel::resolveChoiceId($part, $choice);
        if ($id === '' || !TemplateLayoutModel::exists($id, $part)) { return null; }
        return TemplateLayoutModel::model($id);
    }

    /**
     * Make a Designer meta save visible through the normal WordPress post lifecycle.
     *
     * Canonical Designer data is already persisted before this method is called. The
     * subsequent wp_update_post() deliberately fires post_updated/save_post hooks so
     * WordPress and full-page cache integrations invalidate the old public rendering.
     */
    private static function touchFrontendPage(int $postId, string $desiredStatus, int $version): void
    {
        $post = get_post($postId);
        if (!$post instanceof \WP_Post || $post->post_type !== 'page') {
            throw new \RuntimeException('Frontend-cache kunne ikke invalideres: siden findes ikke længere.');
        }

        $update = ['ID' => $postId];
        if ($desiredStatus !== '') {
            $update['post_status'] = $desiredStatus;
        }

        $updatedPost = wp_update_post($update, true);
        if (is_wp_error($updatedPost)) {
            throw new \RuntimeException('Frontend-cache kunne ikke invalideres: ' . $updatedPost->get_error_message());
        }

        clean_post_cache($postId);
        do_action('h18_clean_designer_page_saved', $postId, $version, (string) get_post_status($postId));
        DiagnosticStore::append($postId, 'frontend_cache_invalidated', [
            'version' => $version,
            'status' => (string) get_post_status($postId),
            'strategy' => 'wp_update_post+clean_post_cache',
        ]);
    }

    private static function redirect(int $postId, string $status, string $message): void
    {
        $url = admin_url('admin.php?page=' . self::MENU);
        if ($postId > 0) {
            $url = add_query_arg('post', $postId, $url);
        }
        $url = add_query_arg([
            'h18_clean_status' => sanitize_key($status),
            'h18_clean_message' => rawurlencode($message),
        ], $url);
        wp_safe_redirect($url);
        exit;
    }

    public static function hideModulePreviewAdminBar(bool $show): bool
    {
        if (isset($_GET['h18_vd_module_preview']) && current_user_can('edit_pages')) {
            return false;
        }
        return $show;
    }

}
