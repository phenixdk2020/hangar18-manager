<?php

declare(strict_types=1);

namespace VisualDesignerManager\Frontend;

use VisualDesignerManager\Model\LayoutModel;
use VisualDesignerManager\Model\ModuleDesignModel;
use VisualDesignerManager\Model\TemplateLayoutModel;
use VisualDesignerManager\Modules\ModuleStore;

/**
 * Responsive geometry layer for Clean Designer.
 *
 * The normal Renderer remains the single HTML renderer. This class only emits
 * breakpoint-specific geometry overrides from the same canonical model.
 */
final class ResponsiveRenderer
{
    public const LAPTOP_MAX = 1180;
    public const TABLET_MAX = 980;
    public const MOBILE_MAX = 782;

    public static function register(): void
    {
        add_action('wp_head', [self::class, 'css'], 1001);
    }

    public static function css(): void
    {
        if (!is_singular('page')) {
            return;
        }

        $postId = get_queried_object_id();
        if ($postId <= 0) {
            return;
        }

        $pageModel = self::model($postId);
        if ($pageModel === null || empty($pageModel['nodes']) || !is_array($pageModel['nodes'])) {
            return;
        }

        $pageScope = ThemeShell::enabled() ? '.h18-vd-live-shell-page ' : '';
        $models = [[
            'scope' => $pageScope,
            'model' => $pageModel,
        ]];
        // Converted V1 pages use V1's natural one-column mobile flow contract.
        // New V3-native pages keep the explicit responsive grid model.
        $legacyPageModel = self::legacyPageModel($postId);
        $v1MobileFlow = $legacyPageModel !== null
            ? self::v1MobileFlowCss($pageModel, $pageScope)
            : '';
        $templateModels = ['header' => null, 'footer' => null];
        $legacyTemplateModels = ['header' => null, 'footer' => null];

        if (ThemeShell::enabled()) {
            foreach (['header', 'footer'] as $part) {
                $templateId = ThemeShell::resolvedTemplateId($postId, $part);
                if ($templateId === '' || !TemplateLayoutModel::exists($templateId, $part)) {
                    continue;
                }
                $templateModel = TemplateLayoutModel::model($templateId);
                if (empty($templateModel['nodes']) || !is_array($templateModel['nodes'])) {
                    continue;
                }
                $models[] = [
                    'scope' => $part === 'header' ? '.h18-vd-live-shell-header ' : '.h18-vd-live-shell-footer ',
                    'model' => $templateModel,
                ];
                $templateModels[$part] = $templateModel;
                $legacyTemplateModels[$part] = self::legacyTemplateModel($templateId, $part);
            }
        }

        $v1MobileVisual = $legacyPageModel !== null
            ? self::v1MobileVisualParityCss(
                $pageModel,
                $legacyPageModel,
                $pageScope,
                is_array($templateModels['header']) ? $templateModels['header'] : null,
                is_array($legacyTemplateModels['header']) ? $legacyTemplateModels['header'] : null,
                is_array($templateModels['footer']) ? $templateModels['footer'] : null,
                is_array($legacyTemplateModels['footer']) ? $legacyTemplateModels['footer'] : null
            )
            : '';
        $v1MobileEdgeSpacing = $legacyPageModel !== null
            ? self::v1MobileEdgeSpacingCss($pageModel, $pageScope)
            : '';
        $v1NestedMobileEdgeParity = $legacyPageModel !== null
            ? self::v1NestedMobileEdgeParityCss($pageModel, $pageScope)
            : '';
        $v1LaptopFluid = $legacyPageModel !== null
            ? self::v1IntermediateFluidGridCss($pageModel, $pageScope, 'laptop')
            : '';
        $v1TabletFluid = $legacyPageModel !== null
            ? self::v1IntermediateFluidGridCss($pageModel, $pageScope, 'tablet')
            : '';
        $v1TabletHeader = $legacyPageModel !== null && is_array($templateModels['header'])
            ? self::v1HeaderMobileCss(
                $templateModels['header'],
                is_array($legacyTemplateModels['header']) ? $legacyTemplateModels['header'] : null,
                '.h18-vd-live-shell-header '
            )
            : '';
        $moduleFooterGap = self::detailModuleFooterGap($postId);
        $pageSpacing = self::pageSpacingCss($pageModel, ThemeShell::enabled() ? '.h18-vd-live-shell-page' : '.h18-clean-page', is_array($templateModels['header']), is_array($templateModels['footer']), $moduleFooterGap);

        $laptop = '';
        $tablet = '';
        $mobile = '';
        foreach ($models as $entry) {
            self::appendModelCss(
                (array) ($entry['model'] ?? []),
                (string) ($entry['scope'] ?? ''),
                $laptop,
                $tablet,
                $mobile
            );
        }

        echo '<style id="h18-clean-responsive-css">';
        echo '.h18-clean-page{max-width:100%;overflow-x:clip}';
        echo '.h18-vd-live-shell,.h18-vd-live-shell-part,.h18-vd-live-shell-part>.h18-clean-page{width:100%;max-width:100%;min-width:0;box-sizing:border-box}';
        echo $pageSpacing['desktop'];
        echo '@media(max-width:' . esc_attr((string) self::LAPTOP_MAX) . 'px){' . $laptop . $v1LaptopFluid . $pageSpacing['laptop'] . '}';
        echo '@media(max-width:' . esc_attr((string) self::TABLET_MAX) . 'px){' . $tablet . $v1TabletFluid . $v1TabletHeader . $pageSpacing['tablet'] . '}';
        echo '@media(max-width:' . esc_attr((string) self::MOBILE_MAX) . 'px){'
            . '.h18-vd-live-shell,.h18-vd-live-shell-part,.h18-clean-page,.h18-clean-front-section,.h18-clean-front-container{min-width:0;max-width:100%;}'
            . '.h18-vd-live-shell{overflow-x:hidden;}'
            . $mobile
            . $v1MobileFlow
            . $v1MobileVisual
            . $v1MobileEdgeSpacing
            . $v1NestedMobileEdgeParity
            . $pageSpacing['mobile'] . '}';
        echo '</style>';
    }

    /** @param array<string,mixed> $model @return array{desktop:string,laptop:string,tablet:string,mobile:string} */
    private static function pageSpacingCss(array $model, string $pageSelector, bool $hasHeader, bool $hasFooter, ?int $moduleFooterGap = null): array
    {
        $raw = isset($model['pageSettings']) && is_array($model['pageSettings']) ? $model['pageSettings'] : [];
        $defaults = [
            'headerGap' => ['desktop'=>32,'laptop'=>32,'tablet'=>24,'mobile'=>24],
            'sectionGap' => ['desktop'=>32,'laptop'=>32,'tablet'=>24,'mobile'=>24],
            'elementGap' => ['desktop'=>16,'laptop'=>16,'tablet'=>14,'mobile'=>14],
            'footerGap' => ['desktop'=>32,'laptop'=>32,'tablet'=>24,'mobile'=>24],
        ];
        $value = static function (string $key, string $device) use ($raw, $defaults): int {
            $fallback = (int) $defaults[$key][$device];
            $candidate = isset($raw[$key][$device]) ? (int) $raw[$key][$device] : $fallback;
            return max(0, min(200, $candidate));
        };
        $out = [];
        foreach (['desktop','laptop','tablet','mobile'] as $device) {
            $header = $hasHeader ? $value('headerGap', $device) : 0;
            $footer = $hasFooter ? ($moduleFooterGap !== null ? max(0, min(200, $moduleFooterGap)) : $value('footerGap', $device)) : 0;
            $footerCss = $moduleFooterGap !== null
                ? 'margin-bottom:0!important;padding-bottom:' . $footer . 'px!important;'
                : 'margin-bottom:' . $footer . 'px!important;';
            $out[$device] = $pageSelector . '{--h18-vdm-page-header-gap:' . $header . 'px;--h18-vdm-page-section-gap:' . $value('sectionGap',$device) . 'px;--h18-vdm-page-element-gap:' . $value('elementGap',$device) . 'px;--h18-vdm-page-footer-gap:' . $footer . 'px;padding-top:' . $header . 'px!important;' . $footerCss . '}';
        }
        return $out;
    }

    private static function detailModuleFooterGap(int $postId): ?int
    {
        $slug = sanitize_title((string) get_post_field('post_name', $postId));
        $collectionSlug = [
            'event-detalje' => 'events',
            'album-detalje' => 'billedgalleri',
            'koeretoej-detalje' => 'koeretoejer-og-materiel',
        ][$slug] ?? '';
        if ($collectionSlug === '') { return null; }
        $collection = get_page_by_path($collectionSlug, OBJECT, 'page');
        if (!$collection instanceof \WP_Post) { return null; }
        $design = ModuleDesignModel::get((int) $collection->ID);
        return max(0, min(200, (int) ($design['footerGap'] ?? 64)));
    }

    /**
     * Emit the same responsive geometry contract for one rendered model.
     * Header, page and Footer models are scoped independently so identical
     * node IDs in different parts cannot overwrite one another.
     *
     * @param array<string,mixed> $model
     */
    private static function appendModelCss(array $model, string $scope, string &$laptop, string &$tablet, string &$mobile): void
    {
        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) {
                continue;
            }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $parent = (string) ($node['parentId'] ?? '');
            $byParent[$parent][] = $node;
        }

        foreach ($byId as $id => $node) {
            $lg = self::effectiveGeometry($node, 'laptop');
            $tg = self::effectiveGeometry($node, 'tablet');
            $mg = self::effectiveGeometry($node, 'mobile');
            $laptopRows = self::effectiveRows($id, 'laptop', $byId, $byParent, []);
            $tabletRows = self::effectiveRows($id, 'tablet', $byId, $byParent, []);
            $mobileRows = self::effectiveRows($id, 'mobile', $byId, $byParent, []);
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $floating = (string) ($node['type'] ?? '') === 'button' && (string) ($props['placementMode'] ?? 'normal') === 'overlay';
            $zIndex = max(1, min(200, (int) ($props['zIndex'] ?? 20)));
            $laptop .= self::geometryCss($selector, $lg, $laptopRows, $floating, $zIndex);
            $tablet .= self::geometryCss($selector, $tg, $tabletRows, $floating, $zIndex);
            $mobile .= self::geometryCss($selector, $mg, $mobileRows, $floating, $zIndex);
        }
    }

    /**
     * Mobile is a responsive projection of the Desktop Designer layout.
     * Desktop visual y/x order is canonical; phone presentation stacks that same
     * node tree to one column without maintaining independent phone placement.
     * Header/Footer may still change presentation (for example hamburger menu),
     * but they use the same canonical nodes, paint and Desktop ordering source.
     *
     * @param array<string,mixed> $model
     */
    private static function v1MobileFlowCss(array $model, string $scope): string
    {
        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $parent = (string) ($node['parentId'] ?? '');
            $byParent[$parent][] = $node;
        }

        $surface = $scope . '.h18-clean-front-surface';
        $section = $scope . '.h18-clean-front-section';
        $container = $scope . '.h18-clean-front-container';
        $css = $surface . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;overflow:visible!important;gap:0!important;grid-template-rows:none!important;grid-auto-rows:auto!important;}'
            . $section . ',' . $container . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;overflow:visible!important;box-sizing:border-box!important;padding:0!important;gap:var(--h18-vdm-page-element-gap,14px)!important;grid-template-columns:1fr!important;grid-template-rows:none!important;grid-auto-rows:auto!important;}'
            . $scope . '.h18-clean-front-event-list,' . $scope . '.h18-clean-front-gallery-list,' . $scope . '.h18-clean-front-gallery-images,' . $scope . '.h18-clean-front-event-facts{grid-template-columns:1fr!important;width:100%!important;max-width:100%!important;gap:16px!important;}'
            . $scope . '.h18-clean-front-event-detail,' . $scope . '.h18-clean-front-gallery-detail,' . $scope . '.h18-clean-front-event-image{width:100%!important;max-width:100%!important;justify-self:stretch!important;box-sizing:border-box!important;}'
            . $scope . '.h18-clean-front-gallery-images img{width:100%!important;height:auto!important;aspect-ratio:4/3;object-fit:cover!important;}'
            . $scope . '.h18-clean-front-event-list img,' . $scope . '.h18-clean-front-gallery-list img{width:100%!important;height:auto!important;aspect-ratio:16/10;object-fit:cover!important;}'
            . $scope . '.h18-clean-front-spacer{display:none!important;height:0!important;min-height:0!important;flex:0 0 0!important;margin:0!important;padding:0!important;}';

        foreach ($byParent as $children) {
            usort($children, static function (array $a, array $b): int {
                // Stack phone content in the same visual order as Desktop.
                $ag = self::effectiveGeometry($a, 'desktop');
                $bg = self::effectiveGeometry($b, 'desktop');
                return ($ag['y'] <=> $bg['y'])
                    ?: ($ag['x'] <=> $bg['x'])
                    ?: ((int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0));
            });

            $previousBottom = 0;
            foreach (array_values($children) as $index => $node) {
                $id = (string) ($node['id'] ?? '');
                if ($id === '') { continue; }
                $g = self::effectiveGeometry($node, 'desktop');
                $rows = self::effectiveRows($id, 'desktop', $byId, $byParent, []);
                $gapRows = $index === 0 ? 0 : max(0, $g['y'] - $previousBottom);
                $gapPx = 0;
                $selector = $scope . '#h18-clean-' . self::cssId($id);
                $type = (string) ($node['type'] ?? '');
                $props = is_array($node['props'] ?? null) ? $node['props'] : [];
                $floating = $type === 'button' && (string) ($props['placementMode'] ?? 'normal') === 'overlay';

                $css .= $selector . '{order:' . $index . '!important;grid-column:auto!important;grid-row:auto!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;width:100%!important;max-width:100%!important;height:auto!important;margin-top:' . $gapPx . 'px!important;margin-right:0!important;margin-bottom:0!important;box-sizing:border-box!important;transform:none!important;}';
                if (!in_array($type, ['image', 'eventimage', 'spacer'], true)) {
                    $css .= $selector . '{height:auto!important;min-height:0!important;}';
                }
                if (in_array($type, ['section', 'container'], true)) {
                    $css .= $selector . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;grid-template-columns:1fr!important;grid-template-rows:none!important;grid-auto-rows:auto!important;height:auto!important;min-height:0!important;padding:0!important;gap:var(--h18-vdm-page-element-gap,14px)!important;overflow:visible!important;}';
                }
                if ($floating) {
                    $css .= $selector . '{z-index:auto!important;}';
                }
                $previousBottom = max($previousBottom, $g['y'] + $rows);
            }
        }
        return $css;
    }

    /**
     * Converted V1 pages keep Desktop as the canonical authoring source, but
     * Laptop/Tablet must not keep Desktop's fixed 8px vertical coordinate grid.
     * That made wide images retain Desktop height (cropping them) and preserved
     * large empty y-gaps at narrower widths. This projection keeps horizontal
     * x/w placement while converting each structural parent to content-sized
     * responsive rows based on the original vertical start positions.
     *
     * @param array<string,mixed> $model
     */
    private static function v1IntermediateFluidGridCss(array $model, string $scope, string $device): string
    {
        if (!in_array($device, ['laptop', 'tablet'], true)) { return ''; }

        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $byParent[(string) ($node['parentId'] ?? '')][] = $node;
        }

        $css = '';
        foreach ($byParent as $parentId => $children) {
            $visible = [];
            foreach ($children as $node) {
                if (!is_array($node) || empty($node['id'])) { continue; }
                if ((string) ($node['type'] ?? '') === 'spacer') {
                    $css .= $scope . '#h18-clean-' . self::cssId((string) $node['id']) . '{display:none!important;}';
                    continue;
                }
                $visible[] = $node;
            }
            if ($visible === []) { continue; }

            usort($visible, static function (array $a, array $b) use ($device): int {
                $ag = self::effectiveGeometry($a, $device);
                $bg = self::effectiveGeometry($b, $device);
                return ($ag['y'] <=> $bg['y'])
                    ?: ($ag['x'] <=> $bg['x'])
                    ?: ((int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0));
            });

            $starts = [];
            foreach ($visible as $node) {
                $starts[] = self::effectiveGeometry($node, $device)['y'];
            }
            $starts = array_values(array_unique($starts));
            sort($starts, SORT_NUMERIC);

            // Very small 8px offsets belong to the same responsive row; this
            // avoids turning micro-alignment offsets into a full element gap.
            $canonicalStarts = [];
            foreach ($starts as $start) {
                if ($canonicalStarts === [] || $start - $canonicalStarts[count($canonicalStarts) - 1] > 1) {
                    $canonicalStarts[] = $start;
                }
            }
            if ($canonicalStarts === []) { $canonicalStarts = [0]; }

            $parentSelector = $parentId === ''
                ? $scope . '.h18-clean-front-surface'
                : $scope . '#h18-clean-' . self::cssId($parentId);
            $gap = $parentId === ''
                ? 'var(--h18-vdm-page-section-gap,' . ($device === 'tablet' ? '24px' : '32px') . ')'
                : 'var(--h18-vdm-page-element-gap,' . ($device === 'tablet' ? '14px' : '16px') . ')';
            $css .= $parentSelector . '{display:grid!important;grid-template-columns:repeat(120,minmax(0,1fr))!important;grid-template-rows:none!important;grid-auto-rows:auto!important;row-gap:' . $gap . '!important;column-gap:0!important;height:auto!important;min-height:0!important;align-items:stretch!important;}';

            foreach ($visible as $node) {
                $id = (string) $node['id'];
                $type = (string) ($node['type'] ?? '');
                $g = self::effectiveGeometry($node, $device);
                $rows = self::effectiveRows($id, $device, $byId, $byParent, []);
                $start = $g['y'];
                $row = 1;
                foreach ($canonicalStarts as $index => $candidate) {
                    if ($candidate <= $start) { $row = $index + 1; }
                    else { break; }
                }
                $end = $start + max(1, $rows);
                $span = 0;
                foreach ($canonicalStarts as $candidate) {
                    if ($candidate >= $start && $candidate < $end) { $span++; }
                }
                $span = max(1, $span);
                $selector = $scope . '#h18-clean-' . self::cssId($id);
                $css .= $selector . '{grid-column:' . ($g['x'] + 1) . '/span ' . $g['w'] . '!important;grid-row:' . $row . '/span ' . $span . '!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;transform:none!important;height:auto!important;min-height:0!important;margin-top:0!important;box-sizing:border-box!important;}';

                if ($type === 'image') {
                    $css .= $selector . ' .h18-clean-front-image{height:auto!important;min-height:0!important;overflow:hidden!important;}'
                        . $selector . ' .h18-clean-front-image img{display:block!important;width:100%!important;height:auto!important;max-width:100%!important;max-height:none!important;object-fit:contain!important;}';
                }
                if ($type === 'button') {
                    $css .= $selector . '{width:max-content!important;min-width:120px!important;max-width:min(280px,calc(100vw - 32px))!important;justify-self:center!important;align-self:start!important;}'
                        . $selector . ' .h18-clean-front-button-link{width:auto!important;height:auto!important;min-width:120px!important;min-height:44px!important;padding:10px 18px!important;white-space:normal!important;line-height:1.2!important;}';
                }
                if (in_array($type, ['section', 'container'], true)) {
                    $css .= $selector . '{overflow:visible!important;}';
                }
            }
        }
        return $css;
    }

    /**
     * V1 phone visual contract reconstructed from the retained V1 runtime and
     * the approved V1 screenshots. This intentionally runs after Alpha.15's
     * flow CSS so it can restore presentation without rewriting stored V3 data.
     *
     * @param array<string,mixed> $pageModel
     * @param array<string,mixed> $legacyPageModel
     * @param array<string,mixed>|null $headerModel
     * @param array<string,mixed>|null $legacyHeaderModel
     * @param array<string,mixed>|null $footerModel
     * @param array<string,mixed>|null $legacyFooterModel
     */
    private static function v1MobileVisualParityCss(
        array $pageModel,
        array $legacyPageModel,
        string $pageScope,
        ?array $headerModel,
        ?array $legacyHeaderModel,
        ?array $footerModel,
        ?array $legacyFooterModel
    ): string {
        $css = '';

        // V1 default mobile typography: body 16px; h1/h2/h3 use the lower
        // clamp bounds 2rem / 1.55rem / 1.2rem at phone widths.
        $css .= $pageScope . '.h18-clean-front-text{font-family:"Inter",Arial,sans-serif!important;font-size:16px!important;line-height:1.5!important;}'
            . $pageScope . 'h1.h18-clean-front-text-heading{font-size:32px!important;line-height:1.2!important;}'
            . $pageScope . 'h2.h18-clean-front-text-heading{font-size:25px!important;line-height:1.18!important;}'
            . $pageScope . 'h3.h18-clean-front-text-heading{font-size:19.2px!important;line-height:1.2!important;}'
            . $pageScope . 'h4.h18-clean-front-text-heading,' . $pageScope . 'h5.h18-clean-front-text-heading,' . $pageScope . 'h6.h18-clean-front-text-heading{font-size:18px!important;line-height:1.2!important;}'
            . $pageScope . '.h18-clean-front-button-link{width:100%!important;height:auto!important;min-height:0!important;padding:14px 18px!important;font-size:16px!important;line-height:1.2!important;box-sizing:border-box!important;}'
            . $pageScope . '.h18-clean-front-surface>.h18-clean-front-spacer{display:none!important;}'
            . $pageScope . '.h18-clean-front-surface>.h18-clean-front-node{margin-bottom:min(var(--h18-vdm-gap-y,24px),24px)!important;}';

        // Paint is owned by the canonical model for every breakpoint.
        // Alpha.27 removes the old mobile-only V1 paint layer so Designer color,
        // border and box edits render identically on desktop and mobile.

        $nodes = [];
        foreach ((array) ($pageModel['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $nodes[(string) $node['id']] = $node;
        }

        $taglineId = '';
        $heroId = '';
        $heroY = PHP_INT_MAX;
        foreach ($nodes as $id => $node) {
            $type = (string) ($node['type'] ?? '');
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $heading = trim(wp_strip_all_tags((string) ($props['heading'] ?? '')));
            $text = trim(wp_strip_all_tags((string) ($props['text'] ?? '')));
            $hay = strtolower($heading . ' ' . $text);
            $selector = $pageScope . '#h18-clean-' . self::cssId($id);

            if ($type === 'text' && str_contains($hay, 'bevaring, restaurering og levende') && str_contains($hay, 'militærhistorie')) {
                $taglineId = $id;
                $css .= $selector . '{text-align:center!important;padding:12px 15px!important;border-radius:0!important;width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;font-family:"Inter",Arial,sans-serif!important;font-size:16px!important;font-weight:650!important;line-height:1.35!important;}';
            }

            if ($type === 'text' && in_array($heading, ['Bevaring', 'Formidling', 'Fællesskab'], true)) {
                $bg = $heading === 'Bevaring' ? '#f2f0e8' : ($heading === 'Formidling' ? '#c3ae83' : '#525a5f');
                $fg = $heading === 'Fællesskab' ? '#ffffff' : '#30382a';
                $css .= $selector . '{width:100%!important;max-width:100%!important;margin:0!important;padding:0!important;border-radius:0!important;background:transparent!important;color:' . $fg . '!important;font-size:16px!important;line-height:1.5!important;}'
                    . $selector . ' .h18-clean-front-text-heading{font-size:19.2px!important;color:' . $fg . '!important;margin-bottom:12px!important;}';
            }

            if ($type === 'image') {
                $g = self::effectiveGeometry($node, 'mobile');
                if ($g['w'] >= 100 && $g['y'] < $heroY) {
                    $heroId = $id;
                    $heroY = $g['y'];
                }
            }
        }

        if ($heroId !== '' && $taglineId !== '') {
            $selector = $pageScope . '#h18-clean-' . self::cssId($heroId);
            $css .= $selector . '{height:155px!important;min-height:155px!important;overflow:hidden!important;margin-bottom:0!important;}'
                . $selector . ' .h18-clean-front-image{height:155px!important;min-height:155px!important;}'
                . $selector . ' .h18-clean-front-image img{width:100%!important;height:155px!important;object-fit:cover!important;object-position:50% 50%!important;}';
        }

        // If old explicit Spacer nodes sat between the mobile hero and tagline,
        // V1's section spacing already represents that air; do not stack them.
        if ($heroId !== '' && $taglineId !== '') {
            $hero = $nodes[$heroId] ?? null;
            $tagline = $nodes[$taglineId] ?? null;
            if (is_array($hero) && is_array($tagline) && (string) ($hero['parentId'] ?? '') === (string) ($tagline['parentId'] ?? '')) {
                $parent = (string) ($hero['parentId'] ?? '');
                $hy = self::effectiveGeometry($hero, 'mobile')['y'];
                $ty = self::effectiveGeometry($tagline, 'mobile')['y'];
                foreach ($nodes as $id => $node) {
                    if ((string) ($node['parentId'] ?? '') !== $parent || (string) ($node['type'] ?? '') !== 'spacer') { continue; }
                    $sy = self::effectiveGeometry($node, 'mobile')['y'];
                    if ($sy >= min($hy, $ty) && $sy <= max($hy, $ty)) {
                        $css .= $pageScope . '#h18-clean-' . self::cssId($id) . '{display:none!important;}';
                    }
                }
            }
        }

        if ($headerModel !== null) {
            $css .= self::v1HeaderMobileCss($headerModel, $legacyHeaderModel, '.h18-vd-live-shell-header ');
        }
        if ($footerModel !== null) {
            $css .= self::v1FooterMobileCss($footerModel, $legacyFooterModel, '.h18-vd-live-shell-footer ');
        }
        return $css;
    }

    /**
     * @param array<string,mixed> $canonical
     * @param array<string,mixed> $legacy
     */
    private static function v1PaintCss(array $canonical, array $legacy, string $scope): string
    {
        $legacyById = [];
        foreach ((array) ($legacy['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $legacyById[(string) $node['id']] = $node;
        }
        $css = '';
        foreach ((array) ($canonical['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $type = (string) ($node['type'] ?? '');
            $legacyNode = $legacyById[$id] ?? null;
            if (!is_array($legacyNode) || (string) ($legacyNode['type'] ?? '') !== $type) { continue; }
            $props = is_array($legacyNode['props'] ?? null) ? $legacyNode['props'] : [];
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $radius = max(0, min(100, (int) ($props['radius'] ?? 0)));
            $borderWidth = max(0, min(20, (int) ($props['borderWidth'] ?? 0)));
            $borderColor = sanitize_hex_color((string) ($props['borderColor'] ?? '#000000')) ?: '#000000';

            if (in_array($type, ['text', 'section', 'container'], true)) {
                $background = !empty($props['backgroundTransparent'])
                    ? 'transparent'
                    : (sanitize_hex_color((string) ($props['background'] ?? '')) ?: 'transparent');
                $css .= $selector . '{background:' . $background . '!important;border-radius:' . $radius . 'px!important;border-width:' . $borderWidth . 'px!important;border-color:' . $borderColor . '!important;}';
            }
            if ($type === 'text') {
                $textColor = sanitize_hex_color((string) ($props['textColor'] ?? '#30382a')) ?: '#30382a';
                $headingColor = sanitize_hex_color((string) ($props['headingColor'] ?? $textColor)) ?: $textColor;
                $css .= $selector . '{color:' . $textColor . '!important;}'
                    . $selector . ' .h18-clean-front-text-heading{color:' . $headingColor . '!important;}';
            }
            if ($type === 'button') {
                $background = sanitize_hex_color((string) ($props['background'] ?? '#30382a')) ?: '#30382a';
                $textColor = sanitize_hex_color((string) ($props['textColor'] ?? '#ffffff')) ?: '#ffffff';
                $css .= $selector . '{--h18-btn-bg:' . $background . '!important;--h18-btn-color:' . $textColor . '!important;}'
                    . $selector . ' .h18-clean-front-button-link{border-radius:' . $radius . 'px!important;border-width:' . $borderWidth . 'px!important;border-color:' . $borderColor . '!important;}';
            }
        }
        return $css;
    }

    /** @param array<string,mixed> $model @param array<string,mixed>|null $legacy */
    private static function templateSurfaceBackground(array $model, ?array $legacy, string $fallback = '#30382a'): string
    {
        // Canonical Designer paint wins. Legacy is fallback only for templates
        // that have not yet stored an explicit surface color.
        foreach ([$model, $legacy] as $candidate) {
            if (!is_array($candidate)) { continue; }
            foreach ((array) ($candidate['nodes'] ?? []) as $node) {
                if (!is_array($node) || !in_array((string) ($node['type'] ?? ''), ['section', 'container'], true)) { continue; }
                $props = is_array($node['props'] ?? null) ? $node['props'] : [];
                if (!empty($props['backgroundTransparent'])) { continue; }
                $color = sanitize_hex_color((string) ($props['background'] ?? ''));
                if ($color) { return $color; }
            }
        }
        return sanitize_hex_color($fallback) ?: '#30382a';
    }

    /** @param array<string,mixed> $model @param array<string,mixed>|null $legacy */
    private static function v1HeaderMobileCss(array $model, ?array $legacy, string $scope): string
    {
        $surfaceBackground = self::templateSurfaceBackground($model, $legacy, '#30382a');
        $css = $scope . '.h18-clean-front-surface{display:flex!important;flex-direction:row!important;align-items:center!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;padding:7px 11px!important;margin:0!important;gap:10px!important;overflow:visible!important;box-sizing:border-box!important;grid-template-columns:none!important;grid-template-rows:none!important;grid-auto-rows:auto!important;background:' . $surfaceBackground . '!important;}'
            . $scope . '.h18-clean-front-section,' . $scope . '.h18-clean-front-container{display:contents!important;width:auto!important;max-width:none!important;height:auto!important;min-height:0!important;padding:0!important;margin:0!important;}'
            . $scope . '.h18-clean-front-node{grid-column:auto!important;grid-row:auto!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;transform:none!important;margin:0!important;height:auto!important;min-height:0!important;box-sizing:border-box!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"]{overflow:visible!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-details{width:auto!important;margin-left:auto!important;overflow:visible!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-summary{display:grid!important;place-items:center!important;width:44px!important;height:44px!important;padding:0!important;border:1px solid var(--h18-menu-color)!important;border-radius:6px!important;background:transparent!important;color:var(--h18-menu-color)!important;cursor:pointer!important;list-style:none!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-panel{display:none!important;position:absolute!important;top:calc(100% + 12px)!important;right:0!important;left:auto!important;width:min(730px,calc(100vw - 32px))!important;max-width:calc(100vw - 32px)!important;padding:22px 24px!important;background:var(--h18-menu-mobile-panel-bg,#f2f0e8)!important;color:var(--h18-menu-mobile-color,#30382a)!important;border:1px solid rgba(48,56,42,.18)!important;border-radius:8px!important;box-shadow:0 10px 30px rgba(0,0,0,.20)!important;z-index:2147482000!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-details.is-open>.h18-clean-front-menu-panel{display:block!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-list{display:flex!important;flex-direction:column!important;align-items:stretch!important;justify-content:flex-start!important;width:100%!important;gap:14px!important;font-size:max(var(--h18-menu-size),20px)!important;font-weight:max(var(--h18-menu-weight),600)!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-list li{width:100%!important;}'
            . $scope . '.h18-clean-front-menu[data-mobile-mode="hamburger"] .h18-clean-front-menu-list a{display:flex!important;align-items:center!important;width:100%!important;min-height:44px!important;padding:4px 10px!important;color:var(--h18-menu-mobile-color,#30382a)!important;white-space:normal!important;text-decoration:none!important;}';

        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $type = (string) ($node['type'] ?? '');
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $css .= $selector . '{height:auto!important;min-height:0!important;margin:0!important;}';
            if (in_array($type, ['section','container'], true)) {
                $css .= $selector . '{display:contents!important;grid-template-columns:none!important;grid-auto-rows:auto!important;grid-template-rows:none!important;width:auto!important;max-width:none!important;height:auto!important;min-height:0!important;padding:0!important;margin:0!important;}';
            }
            if ($type === 'image') {
                $css .= $selector . '{flex:0 0 70px!important;width:70px!important;max-width:70px!important;height:auto!important;align-self:center!important;}'
                    . $selector . ' .h18-clean-front-image,' . $selector . ' .h18-clean-front-image img{width:70px!important;height:auto!important;max-width:70px!important;object-fit:contain!important;}';
            } elseif ($type === 'text') {
                $font = max(13.0, min(19.0, (float) ((int) ($props['fontSize'] ?? 19))));
                if (str_contains($id, 'legacy-header')) { $font = max(13.0, min(19.0, $font * 0.70)); }
                $css .= $selector . '{flex:1 1 0!important;width:auto!important;min-width:0!important;max-width:none!important;height:auto!important;padding:0!important;background:transparent!important;color:#f2f0e8!important;font-family:"Inter",Arial,sans-serif!important;font-size:17px!important;font-weight:750!important;line-height:1.15!important;text-align:left!important;overflow-wrap:normal!important;word-break:normal!important;}'
                    . $selector . ' .h18-clean-front-text-heading{font-size:inherit!important;color:#f2f0e8!important;margin:0!important;}';
            } elseif ($type === 'menu') {
                $css .= $selector . '{flex:0 0 44px!important;width:44px!important;max-width:44px!important;height:44px!important;margin:0 0 0 auto!important;padding:0!important;background:transparent!important;align-self:center!important;}'
                    . $selector . ' .h18-clean-front-menu-summary{width:44px!important;height:44px!important;border-width:1px!important;border-radius:6px!important;}';
            }
        }
        return $css;
    }

    /** @param array<string,mixed> $model @param array<string,mixed>|null $legacy */
    private static function v1FooterMobileCss(array $model, ?array $legacy, string $scope): string
    {
        $surfaceBackground = self::templateSurfaceBackground($model, $legacy, '#30382a');
        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $byParent[(string) ($node['parentId'] ?? '')][] = $node;
        }

        $css = $scope . '.h18-clean-front-surface,' . $scope . '.h18-clean-front-section,' . $scope . '.h18-clean-front-container{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;overflow:visible!important;box-sizing:border-box!important;grid-auto-rows:auto!important;grid-template-rows:none!important;}'
            . $scope . '.h18-clean-front-surface{padding:32px 15px 20px!important;margin:0!important;background:' . $surfaceBackground . '!important;}'
            . $scope . '.h18-clean-front-section,' . $scope . '.h18-clean-front-container{padding:0!important;margin:0!important;}'
            . $scope . '.h18-clean-front-node{grid-column:auto!important;grid-row:auto!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;transform:none!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;margin-right:0!important;margin-bottom:0!important;box-sizing:border-box!important;}'
            . $scope . '.h18-clean-front-text{font-size:14px!important;line-height:1.45!important;}'
            . $scope . '.h18-clean-front-text a{display:inline!important;color:inherit!important;text-decoration:none!important;}'
            . $scope . '.h18-clean-front-button-link{min-height:44px!important;padding:10px 16px!important;font-size:16px!important;font-weight:700!important;line-height:1.2!important;}'
            . $scope . '.h18-clean-front-menu-summary{display:none!important;}'
            . $scope . '.h18-clean-front-menu-panel{display:block!important;position:static!important;width:100%!important;max-width:100%!important;padding:0!important;background:transparent!important;border:0!important;box-shadow:none!important;}'
            . $scope . '.h18-clean-front-menu-list{display:flex!important;flex-direction:column!important;align-items:flex-start!important;gap:8px!important;font-size:14px!important;font-weight:400!important;}'
            . $scope . '#h18-clean-text-footer-brand-v0147{font-size:18px!important;font-weight:700!important;line-height:1.25!important;}'
            . $scope . '#h18-clean-text-footer-description-v0147{font-size:14px!important;font-weight:400!important;line-height:1.45!important;}'
            . $scope . '#h18-clean-text-footer-shortcuts-heading-v0147,' . $scope . '#h18-clean-text-footer-association-heading-v0147{font-size:14px!important;font-weight:600!important;line-height:1.2!important;}'
            . $scope . '#h18-clean-text-footer-copyright-v0147{font-size:11px!important;font-weight:400!important;line-height:1.3!important;text-align:center!important;white-space:nowrap!important;}';

        // Responsive geometry is emitted as ID rules before this pass. Reset each
        // footer node with the same specificity so stale 656px/desktop heights cannot win.
        foreach ($byId as $id => $node) {
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $css .= $selector . '{grid-column:auto!important;grid-row:auto!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;transform:none!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;margin-right:0!important;margin-bottom:0!important;box-sizing:border-box!important;}';
            if (in_array((string) ($node['type'] ?? ''), ['section','container'], true)) {
                $css .= $selector . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;grid-template-columns:1fr!important;grid-auto-rows:auto!important;grid-template-rows:none!important;height:auto!important;min-height:0!important;padding:0!important;}';
            }
        }

        foreach ($byParent as $children) {
            usort($children, static function (array $a, array $b): int {
                $ag = self::effectiveGeometry($a, 'mobile');
                $bg = self::effectiveGeometry($b, 'mobile');
                return ($ag['y'] <=> $bg['y']) ?: ((int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0));
            });
            $previousBottom = 0;
            foreach (array_values($children) as $index => $node) {
                $id = (string) ($node['id'] ?? '');
                if ($id === '') { continue; }
                $g = self::effectiveGeometry($node, 'mobile');
                $rows = self::effectiveRows($id, 'mobile', $byId, $byParent, []);
                $gapRows = $index === 0 ? 0 : max(0, $g['y'] - $previousBottom);
                $gapPx = min(32, $gapRows * LayoutModel::ROW_PX);
                $css .= $scope . '#h18-clean-' . self::cssId($id) . '{order:' . $index . '!important;margin-top:' . $gapPx . 'px!important;}';
                $previousBottom = max($previousBottom, $g['y'] + $rows);
            }
        }
        // Alpha.29: stack the canonical three Desktop Footer columns as
        // complete groups on phones. Alpha.28's global Desktop y-sort is correct
        // for page content, but would interleave nodes from parallel Footer columns.
        $footerStack = [
            'text-footer-brand-v0147' => [10, 0],
            'text-footer-description-v0147' => [20, 8],
            'text-footer-shortcuts-heading-v0147' => [30, 20],
            'menu-footer-shortcuts-v3' => [40, 6],
            'text-footer-association-heading-v0147' => [50, 20],
            'button-footer-join-v0147' => [60, 10],
            'button-footer-contact-v0147' => [70, 8],
            'container-footer-divider-v0147' => [80, 20],
            'text-footer-copyright-v0147' => [90, 12],
        ];
        foreach ($footerStack as $footerId => $stack) {
            if (!isset($byId[$footerId])) { continue; }
            $css .= $scope . '#h18-clean-' . self::cssId($footerId)
                . '{order:' . $stack[0] . '!important;margin-top:' . $stack[1] . 'px!important;}';
        }

        // Alpha.30: V1 footer rhythm. Alpha.24/26 already established the
        // measured 32/15/20 outer padding and V1 typography, so retain those
        // values and remove only the extra inner whitespace introduced by the
        // grouped Alpha.29 stack.
        $css .= $scope . '.h18-clean-front-surface{gap:0!important;}'
            . $scope . '#h18-clean-text-footer-brand-v0147 .h18-clean-front-text-heading,'
            . $scope . '#h18-clean-text-footer-brand-v0147 .h18-clean-front-text-body,'
            . $scope . '#h18-clean-text-footer-description-v0147 .h18-clean-front-text-heading,'
            . $scope . '#h18-clean-text-footer-description-v0147 .h18-clean-front-text-body,'
            . $scope . '#h18-clean-text-footer-shortcuts-heading-v0147 .h18-clean-front-text-heading,'
            . $scope . '#h18-clean-text-footer-shortcuts-heading-v0147 .h18-clean-front-text-body,'
            . $scope . '#h18-clean-text-footer-association-heading-v0147 .h18-clean-front-text-heading,'
            . $scope . '#h18-clean-text-footer-association-heading-v0147 .h18-clean-front-text-body,'
            . $scope . '#h18-clean-text-footer-copyright-v0147 .h18-clean-front-text-heading,'
            . $scope . '#h18-clean-text-footer-copyright-v0147 .h18-clean-front-text-body{margin-top:0!important;margin-bottom:0!important;}'
            . $scope . '#h18-clean-text-footer-description-v0147 p,'
            . $scope . '#h18-clean-text-footer-copyright-v0147 p{margin-top:0!important;margin-bottom:0!important;}'
            . $scope . '#h18-clean-menu-footer-shortcuts-v3 .h18-clean-front-menu-list{gap:6px!important;line-height:1.35!important;margin:0!important;padding:0!important;}'
            . $scope . '#h18-clean-menu-footer-shortcuts-v3 .h18-clean-front-menu-list a{padding-top:0!important;padding-bottom:0!important;line-height:1.35!important;}'
            . $scope . '#h18-clean-button-footer-join-v0147,'
            . $scope . '#h18-clean-button-footer-contact-v0147{width:100%!important;max-width:100%!important;}'
            . $scope . '#h18-clean-button-footer-join-v0147 .h18-clean-front-button-link,'
            . $scope . '#h18-clean-button-footer-contact-v0147 .h18-clean-front-button-link{width:100%!important;min-height:44px!important;padding:11px 16px!important;font-size:14px!important;line-height:1.25!important;box-sizing:border-box!important;}'
            . $scope . '#h18-clean-container-footer-divider-v0147{width:100%!important;max-width:100%!important;padding:0!important;}'
            . $scope . '#h18-clean-text-footer-copyright-v0147{padding:0!important;}';
        return $css;
    }

    /** @return array<string,mixed>|null */
    private static function legacyPageModel(int $postId): ?array
    {
        if (!metadata_exists('post', $postId, '_h18_clean_layout_v1')) { return null; }
        $raw = get_post_meta($postId, '_h18_clean_layout_v1', true);
        if (!is_array($raw)) { return null; }
        try { return LayoutModel::normalize($raw); } catch (\Throwable $error) { return null; }
    }

    /** @return array<string,mixed>|null */
    private static function legacyTemplateModel(string $templateId, string $part): ?array
    {
        $part = $part === 'footer' ? 'footer' : 'header';
        $candidates = ['h18_clean_tpl_' . $templateId . '_model_v1'];
        if ($templateId === $part . '-standard-v1') {
            array_unshift($candidates, 'h18_clean_global_' . $part . '_layout_v1');
        }
        foreach ($candidates as $option) {
            $raw = get_option($option, null);
            if (!is_array($raw)) { continue; }
            try { return LayoutModel::normalize($raw); } catch (\Throwable $error) { continue; }
        }
        return null;
    }

    /**
     * Alpha.18 V1 mobile edge/spacing contract.
     *
     * The approved Alpha.17 screenshots show the structure is now correct,
     * but the V3 page wrapper still leaves gutters around top-level V1 bands
     * and several old spacing mechanisms can accumulate. V1 instead paints
     * major page bands to the viewport edge and uses one controlled section
     * gap. Feature cards (Bevaring/Formidling/Fællesskab) remain inset.
     *
     * @param array<string,mixed> $model
     */
    private static function v1MobileEdgeSpacingCss(array $model, string $scope): string
    {
        $root = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            if ((string) ($node['parentId'] ?? '') !== '') { continue; }
            $root[] = $node;
        }
        usort($root, static function (array $a, array $b): int {
            $ag = self::effectiveGeometry($a, 'mobile');
            $bg = self::effectiveGeometry($b, 'mobile');
            return ($ag['y'] <=> $bg['y'])
                ?: ($ag['x'] <=> $bg['x'])
                ?: ((int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0));
        });

        $css = $scope . '.h18-clean-front-surface{width:100%!important;max-width:none!important;padding-left:0!important;padding-right:0!important;gap:0!important;overflow-x:clip!important;}'
            . $scope . '.h18-clean-front-surface>.h18-clean-front-spacer{display:none!important;height:0!important;min-height:0!important;margin:0!important;padding:0!important;}'
            . $scope . '.h18-clean-front-surface>.h18-clean-front-node{margin-bottom:0!important;}';

        $visible = 0;
        $previousFeature = false;
        foreach ($root as $node) {
            $id = (string) ($node['id'] ?? '');
            $type = (string) ($node['type'] ?? '');
            if ($id === '' || $type === 'spacer') { continue; }
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $heading = trim(wp_strip_all_tags((string) ($props['heading'] ?? '')));
            $feature = $type === 'text' && in_array($heading, ['Bevaring', 'Formidling', 'Fællesskab'], true);
            $gap = $visible === 0 ? '0px' : (($feature && $previousFeature) ? 'var(--h18-vdm-page-element-gap,14px)' : 'var(--h18-vdm-page-section-gap,24px)');
            $selector = $scope . '#h18-clean-' . self::cssId($id);

            // One and only one vertical gap between visible top-level sections.
            $css .= $selector . '{margin-top:' . $gap . '!important;margin-bottom:0!important;}';

            if ($feature) {
                // V1 feature cards are intentionally inset; Alpha.16 paint/size
                // remains authoritative here.
                $css .= $selector . '{margin-left:10px!important;margin-right:10px!important;}';
            } elseif (in_array($type, ['image', 'text', 'section', 'container', 'eventlist', 'gallerylist', 'eventdetail', 'gallerydetail'], true)) {
                // Major V1 page bands paint to the physical viewport edge even
                // when the WordPress/page shell itself has a content gutter.
                $css .= $selector . '{width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;box-sizing:border-box!important;}';
                if (in_array($type, ['text', 'section', 'container'], true)) {
                    $css .= $selector . '{padding-left:0!important;padding-right:0!important;border-radius:0!important;}';
                }
                if ($type === 'image') {
                    $css .= $selector . '{padding-left:0!important;padding-right:0!important;border-radius:0!important;overflow:hidden!important;}'
                        . $selector . ' .h18-clean-front-image,' . $selector . ' .h18-clean-front-image img{width:100%!important;max-width:100%!important;border-radius:0!important;}';
                }
            }

            $visible++;
            $previousFeature = $feature;
        }
        return $css;
    }

    /**
     * Alpha.19 nested mobile edge parity.
     *
     * Alpha.18 only matched root nodes. The migrated V3 home page keeps the
     * hero, tagline and most visual page bands inside Section/Container nodes,
     * so those root-only selectors did not affect the actual phone DOM. This
     * pass walks the complete node tree and targets the semantic V1 bands by
     * node type/content while keeping the approved feature cards inset.
     *
     * @param array<string,mixed> $model
     */
    private static function v1NestedMobileEdgeParityCss(array $model, string $scope): string
    {
        $byId = [];
        $children = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $parent = (string) ($node['parentId'] ?? '');
            $children[$parent][] = $node;
        }

        $taglineId = '';
        $heroId = '';
        $heroY = PHP_INT_MAX;
        $majorIds = [];
        $featureIds = [];
        $majorHeadings = ['Om foreningen', 'Køretøjer og materiel', 'Events', 'Billedgalleri', 'Bliv en del af foreningen', 'Kontakt os'];

        foreach ($byId as $id => $node) {
            $type = (string) ($node['type'] ?? '');
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $heading = trim(wp_strip_all_tags((string) ($props['heading'] ?? '')));
            $text = trim(wp_strip_all_tags((string) ($props['text'] ?? '')));
            $hay = strtolower($heading . ' ' . $text);

            if ($type === 'text' && str_contains($hay, 'bevaring, restaurering og levende') && str_contains($hay, 'militærhistorie')) {
                $taglineId = $id;
            }
            if ($type === 'text' && in_array($heading, ['Bevaring', 'Formidling', 'Fællesskab'], true)) {
                $featureIds[$id] = $heading;
            }
            if ($type === 'text' && in_array($heading, $majorHeadings, true)) {
                $majorIds[$id] = true;
            }
            if ($type === 'image') {
                $g = self::effectiveGeometry($node, 'mobile');
                if ($g['w'] >= 100 && $g['y'] < $heroY) {
                    $heroId = $id;
                    $heroY = $g['y'];
                }
            }
        }

        $nearestBand = static function (string $id) use ($byId): string {
            $node = $byId[$id] ?? null;
            if (!is_array($node)) { return $id; }
            $parent = (string) ($node['parentId'] ?? '');
            $guard = 0;
            while ($parent !== '' && isset($byId[$parent]) && $guard++ < 32) {
                $candidate = $byId[$parent];
                $type = (string) ($candidate['type'] ?? '');
                if (in_array($type, ['section', 'container'], true)) { return $parent; }
                $parent = (string) ($candidate['parentId'] ?? '');
            }
            return $id;
        };

        $ancestorChain = static function (string $id) use ($byId): array {
            $result = [];
            $node = $byId[$id] ?? null;
            $parent = is_array($node) ? (string) ($node['parentId'] ?? '') : '';
            $guard = 0;
            while ($parent !== '' && isset($byId[$parent]) && $guard++ < 32) {
                $result[] = $parent;
                $parent = (string) ($byId[$parent]['parentId'] ?? '');
            }
            return $result;
        };

        $css = $scope . '.h18-clean-front-surface{padding-left:0!important;padding-right:0!important;overflow-x:clip!important;}'
            . $scope . '.h18-clean-front-spacer{display:none!important;height:0!important;min-height:0!important;flex-basis:0!important;margin:0!important;padding:0!important;}';

        // Structural wrappers on the hero/tagline paths must not contribute an
        // additional 24px flow margin or internal horizontal gutter.
        $pathIds = [];
        foreach (array_filter([$heroId, $taglineId]) as $semanticId) {
            foreach ($ancestorChain($semanticId) as $ancestorId) { $pathIds[$ancestorId] = true; }
        }
        foreach (array_keys($pathIds) as $id) {
            $node = $byId[$id] ?? null;
            if (!is_array($node) || !in_array((string) ($node['type'] ?? ''), ['section', 'container'], true)) { continue; }
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $css .= $selector . '{width:100%!important;max-width:100%!important;margin-top:0!important;margin-bottom:0!important;padding:0!important;gap:0!important;overflow:visible!important;}';
        }

        if ($heroId !== '') {
            $selector = $scope . '#h18-clean-' . self::cssId($heroId);
            $css .= $selector . '{width:100%!important;max-width:100%!important;height:155px!important;min-height:155px!important;margin-left:0!important;margin-right:0!important;margin-top:0!important;margin-bottom:0!important;padding:0!important;border-radius:0!important;overflow:hidden!important;}'
                . $selector . ' .h18-clean-front-image{width:100%!important;max-width:100%!important;height:155px!important;min-height:155px!important;margin:0!important;padding:0!important;border-radius:0!important;}'
                . $selector . ' .h18-clean-front-image img{display:block!important;width:100%!important;max-width:100%!important;height:155px!important;object-fit:cover!important;object-position:50% 50%!important;border-radius:0!important;}';
        }

        if ($taglineId !== '') {
            $selector = $scope . '#h18-clean-' . self::cssId($taglineId);
            $css .= $selector . '{width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;margin-top:var(--h18-vdm-page-section-gap,24px)!important;margin-bottom:0!important;padding:12px 15px!important;border-radius:0!important;font-family:"Inter",Arial,sans-serif!important;font-size:16px!important;font-weight:650!important;line-height:1.35!important;text-align:center!important;box-sizing:border-box!important;}';
        }

        foreach (array_keys($majorIds) as $id) {
            $bandId = $nearestBand($id);
            $selector = $scope . '#h18-clean-' . self::cssId($bandId);
            $css .= $selector . '{width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;margin-top:var(--h18-vdm-page-section-gap,24px)!important;margin-bottom:0!important;padding:30px 15px!important;box-sizing:border-box!important;border-radius:0!important;overflow:visible!important;gap:var(--h18-vdm-page-element-gap,14px)!important;}';
        }

        // Full-width semantic bands must not remain trapped inside a
        // Section/Container with inherited horizontal padding. Alpha.19 fixed
        // the band itself; Alpha.20 also clears every structural ancestor on
        // that path. This is mobile-only generated CSS and does not mutate data.
        $majorWrapperIds = [];
        foreach (array_keys($majorIds) as $semanticId) {
            $bandId = $nearestBand($semanticId);
            foreach ($ancestorChain($bandId) as $ancestorId) {
                $majorWrapperIds[$ancestorId] = true;
            }
        }
        foreach (array_keys($majorWrapperIds) as $id) {
            $node = $byId[$id] ?? null;
            if (!is_array($node) || !in_array((string) ($node['type'] ?? ''), ['section', 'container'], true)) { continue; }
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $css .= $selector . '{width:100%!important;max-width:100%!important;margin-left:0!important;margin-right:0!important;margin-top:0!important;margin-bottom:0!important;padding:0!important;gap:0!important;overflow:visible!important;}';
        }

        // Preserve V1's inset Bevaring/Formidling/Fællesskab cards even when
        // their parent wrapper is full-width.
        foreach ($featureIds as $id => $heading) {
            $bandId = $nearestBand($id);
            $bandSelector = $scope . '#h18-clean-' . self::cssId($bandId);
            $textSelector = $scope . '#h18-clean-' . self::cssId($id);
            $bg = $heading === 'Bevaring' ? '#f2f0e8' : ($heading === 'Formidling' ? '#c3ae83' : '#525a5f');
            $fg = $heading === 'Fællesskab' ? '#ffffff' : '#30382a';
            $css .= $bandSelector . '{width:calc(100% - 20px)!important;max-width:calc(100% - 20px)!important;margin-left:10px!important;margin-right:10px!important;margin-top:0!important;margin-bottom:0!important;padding:18px!important;border-radius:8px!important;background:' . $bg . '!important;color:' . $fg . '!important;box-sizing:border-box!important;}'
                . $textSelector . '{width:100%!important;max-width:100%!important;margin:0!important;padding:0!important;border-radius:0!important;background:transparent!important;color:' . $fg . '!important;}'
                . $textSelector . ' .h18-clean-front-text-heading{color:' . $fg . '!important;margin-bottom:12px!important;}';
        }

        return $css;
    }

    /** @return array<string,mixed>|null */
    private static function model(int $postId): ?array
    {
        $preview = self::previewModel($postId);
        if ($preview !== null) {
            return $preview;
        }
        if (!metadata_exists('post', $postId, LayoutModel::META)) {
            return null;
        }
        return LayoutModel::get($postId);
    }

    /** @return array<string,mixed>|null */
    private static function previewModel(int $postId): ?array
    {
        if (!is_user_logged_in() || !current_user_can('edit_pages')) {
            return null;
        }
        $token = isset($_GET['h18_clean_preview']) ? sanitize_key((string) wp_unslash($_GET['h18_clean_preview'])) : '';
        if ($token === '' || !preg_match('/^[a-z0-9]{12,64}$/', $token)) {
            return null;
        }
        $raw = get_transient(Renderer::previewKey(get_current_user_id(), $postId, $token));
        if (!is_array($raw)) {
            return null;
        }
        try {
            return LayoutModel::normalize($raw);
        } catch (\Throwable $error) {
            return null;
        }
    }

    /** @param array<string,mixed> $node @return array{x:int,y:int,w:int,h:int} */
    private static function effectiveGeometry(array $node, string $device): array
    {
        $geometry = is_array($node['geometry'] ?? null) ? $node['geometry'] : [];
        $desktop = self::geometry($geometry['desktop'] ?? null);
        if ($device === 'desktop') {
            return $desktop;
        }

        $laptopRaw = is_array($geometry['laptop'] ?? null) ? $geometry['laptop'] : [];
        $laptop = !empty($laptopRaw['inheritDesktop']) ? $desktop : self::geometry($laptopRaw, $desktop);
        if ($device === 'laptop') {
            return $laptop;
        }

        $tabletRaw = is_array($geometry['tablet'] ?? null) ? $geometry['tablet'] : [];
        $tablet = !empty($tabletRaw['inheritDesktop']) ? $laptop : self::geometry($tabletRaw, $laptop);
        if ($device === 'tablet') {
            return $tablet;
        }

        // Alpha.28: Desktop is the canonical phone layout source. Mobile
        // presentation can stack/resize through generated CSS, but placement and
        // ordering never come from a second mobile geometry model.
        return $desktop;
    }

    /** @param mixed $raw @param array{x:int,y:int,w:int,h:int}|null $fallback @return array{x:int,y:int,w:int,h:int} */
    private static function geometry(mixed $raw, ?array $fallback = null): array
    {
        $fallback ??= ['x' => 0, 'y' => 0, 'w' => LayoutModel::UNITS, 'h' => 0];
        if (!is_array($raw)) {
            return $fallback;
        }
        $x = max(0, min(LayoutModel::UNITS - 1, (int) ($raw['x'] ?? $fallback['x'])));
        $w = max(1, min(LayoutModel::UNITS - $x, (int) ($raw['w'] ?? $fallback['w'])));
        return [
            'x' => $x,
            'y' => max(0, min(10000, (int) ($raw['y'] ?? $fallback['y']))),
            'w' => $w,
            'h' => max(0, min(4000, (int) ($raw['h'] ?? $fallback['h']))),
        ];
    }

    /**
     * Runtime auto-grow for a breakpoint. This is deliberately derived from
     * canonical child geometry so responsive parents cannot visually overlap
     * following siblings merely because their children were stacked on Mobile.
     *
     * @param array<string,array<string,mixed>> $byId
     * @param array<string,array<int,array<string,mixed>>> $byParent
     * @param array<string,bool> $seen
     */
    private static function effectiveRows(string $id, string $device, array $byId, array $byParent, array $seen): int
    {
        if (!isset($byId[$id]) || isset($seen[$id])) {
            return 1;
        }
        $seen[$id] = true;
        $node = $byId[$id];
        $g = self::effectiveGeometry($node, $device);
        $type = (string) ($node['type'] ?? '');
        $base = $g['h'] > 0 ? $g['h'] : (in_array($type, ['text', 'image'], true) ? 10 : 8);
        if ($type === 'gallerydetail') { $base = max($base, self::galleryDetailRows($node, $device)); }
        if ($type === 'eventfacts' && $device === 'mobile') { $base = max($base, 42); }

        if (!in_array($type, ['section', 'container'], true)) {
            return max(1, $base);
        }

        $required = 0;
        foreach ($byParent[$id] ?? [] as $child) {
            $childProps = is_array($child['props'] ?? null) ? $child['props'] : [];
            if ((string) ($child['type'] ?? '') === 'button' && (string) ($child['parentId'] ?? '') !== '' && (string) ($childProps['placementMode'] ?? 'normal') === 'overlay') { continue; }
            $childId = (string) ($child['id'] ?? '');
            if ($childId === '') {
                continue;
            }
            $cg = self::effectiveGeometry($child, $device);
            $required = max($required, $cg['y'] + self::effectiveRows($childId, $device, $byId, $byParent, $seen));
        }

        $props = is_array($node['props'] ?? null) ? $node['props'] : [];
        $legacyPadding = max(0, (int) ($props['padding'] ?? 0));
        $paddingTop = max(0, (int) ($props['paddingTop'] ?? $legacyPadding));
        $paddingBottom = max(0, (int) ($props['paddingBottom'] ?? $legacyPadding));
        $extraPx = $paddingTop + $paddingBottom + (max(0, (int) ($props['borderWidth'] ?? 0)) * 2);
        $required += (int) ceil($extraPx / LayoutModel::ROW_PX);
        return max(1, $base, $required);
    }

    /** @param array<string,mixed> $node */
    private static function galleryDetailRows(array $node, string $device): int
    {
        $props = is_array($node['props'] ?? null) ? $node['props'] : [];
        $recordId = strtolower(trim((string) ($props['recordId'] ?? '')));
        if ($recordId === '') { $recordId = strtolower(trim(sanitize_text_field((string) wp_unslash($_GET['h18_gallery'] ?? '')))); }
        $count = 0; $hasDescription = false;
        if ($recordId !== '' && preg_match('/^[a-z0-9][a-z0-9._:-]{0,127}$/', $recordId)) {
            $found = ModuleStore::findByRecordId('galleries', $recordId);
            $record = is_array($found) && isset($found['record']) && is_array($found['record']) ? $found['record'] : null;
            if (is_array($record)) {
                $fields = isset($record['fields']) && is_array($record['fields']) ? $record['fields'] : [];
                $ids = isset($fields['imageIds']) && is_array($fields['imageIds']) ? array_values(array_filter(array_map('absint', $fields['imageIds']))) : [];
                $count = count($ids);
                $hasDescription = !empty($props['showDescription']) && trim((string) ($fields['description'] ?? '')) !== '';
            }
        }
        $columns = $device === 'mobile' ? 1 : ($device === 'tablet' ? min(2, max(1, (int) ($props['columns'] ?? 4))) : max(1, min(6, (int) ($props['columns'] ?? 4))));
        $imageHeight = max(80, min(700, (int) ($props['imageHeight'] ?? 220)));
        $gap = max(0, min(80, (int) ($props['gap'] ?? 12)));
        $padding = max(0, min(80, (int) ($props['padding'] ?? 16)));
        $imageRows = $count > 0 ? (int) ceil($count / $columns) : 0;
        $px = 88 + ($hasDescription ? 144 : 0) + ($padding * 2);
        if ($imageRows > 0) { $px += ($imageRows * $imageHeight) + (max(0, $imageRows - 1) * $gap); }
        return max(8, (int) ceil($px / LayoutModel::ROW_PX));
    }

    /** @param array{x:int,y:int,w:int,h:int} $g */
    private static function geometryCss(string $selector, array $g, int $rows, bool $floating = false, int $zIndex = 20): string
    {
        $rows = max(1, $rows);
        if ($floating) {
            $left = ($g['x'] / LayoutModel::UNITS) * 100;
            $width = ($g['w'] / LayoutModel::UNITS) * 100;
            return $selector . '{position:absolute!important;left:' . $left . '%!important;top:' . (max(0, $g['y']) * LayoutModel::ROW_PX) . 'px!important;'
                . 'width:' . $width . '%!important;height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;min-height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;'
                . 'z-index:' . max(1, min(200, $zIndex)) . '!important;grid-column:auto!important;grid-row:auto!important;margin-top:0!important;}';
        }
        $row = max(0, $g['y']) + 1;
        return $selector . '{grid-column:' . ($g['x'] + 1) . '/span ' . $g['w'] . '!important;'
            . 'grid-row:' . $row . '/span ' . $rows . '!important;'
            . 'min-height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;'
            . 'margin-top:0!important;}';
    }

    private static function cssId(string $id): string
    {
        // Clean IDs are already normalized to [a-z0-9._-]. CSS.escape is not
        // available server-side, so escape the only CSS-special punctuation.
        return str_replace(['.', ':'], ['\\.', '\\:'], $id);
    }
}
