<?php

declare(strict_types=1);

defined('ABSPATH') || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
<style id="vdm-site-shell-reset">
body.vdm-site-shell{margin:0;padding:0;width:100%;min-width:0;max-width:none;overflow-x:hidden}
body.vdm-site-shell #vdm-site-shell-root{display:block;width:100%;max-width:none;margin:0;padding:0;box-sizing:border-box}
body.vdm-site-shell .h18-vd-live-shell,body.vdm-site-shell .h18-vd-live-shell-part{display:block;width:100%;max-width:none;margin:0;padding:0;box-sizing:border-box}
body.vdm-site-shell .h18-vd-live-shell-page{min-width:0}
</style>
</head>
<body <?php body_class('vdm-site-shell'); ?>>
<?php wp_body_open(); ?>
<div id="vdm-site-shell-root" data-vdm-site-shell="active">
<?php
if (have_posts()) {
    while (have_posts()) {
        the_post();
        the_content();
    }
}
?>
</div>
<?php wp_footer(); ?>
</body>
</html>
