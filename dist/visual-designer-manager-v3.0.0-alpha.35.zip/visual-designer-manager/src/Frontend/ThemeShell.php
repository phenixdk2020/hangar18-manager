<?php

declare(strict_types=1);

namespace VisualDesignerManager\Frontend;

use VisualDesignerManager\Model\LayoutModel;
use VisualDesignerManager\Model\TemplateLayoutModel;

/**
 * Theme-shell coordination for the Visual Designer runtime.
 *
 * 0.1.49 activates the approved cutover for Visual Designer pages.
 * Non-Visual-Designer WordPress pages remain untouched as a safe fallback.
 */
final class ThemeShell
{
    public const CUTOVER_OPTION = 'h18_visual_designer_theme_shell_cutover_v1';
    private const V0149_ACTIVATED_OPTION = 'h18_visual_designer_theme_shell_cutover_v0149_activated';

    public static function register(): void
    {
        add_action('init', [self::class, 'activateApprovedCutover'], 1);
        add_filter('body_class', [self::class, 'bodyClasses'], 50);
        add_filter('template_include', [self::class, 'templateInclude'], 999);
    }

    /**
     * 0.1.49 is the explicit, user-approved cutover point. This runs once.
     * A rollback to an older plugin stays safe because older Renderers ignore
     * the flag, while non-Visual-Designer pages are never wrapped by 0.1.49.
     */
    public static function activateApprovedCutover(): void
    {
        if (get_option(self::V0149_ACTIVATED_OPTION, false)) {
            return;
        }
        update_option(self::CUTOVER_OPTION, '1', false);
        update_option(self::V0149_ACTIVATED_OPTION, [
            'activatedUtc' => gmdate('c'),
            'version' => defined('VDM_VERSION') ? VDM_VERSION : '0.1.49',
            'scope' => 'visual-designer-pages-only',
        ], false);
    }

    public static function enabled(): bool
    {
        return get_option(self::CUTOVER_OPTION, '0') === '1';
    }

    /** @param array<int,string> $classes @return array<int,string> */
    public static function bodyClasses(array $classes): array
    {
        $classes[] = 'h18-vd-theme-shell-ready';
        if (self::enabled()) {
            $classes[] = 'h18-vd-theme-shell-active';
        }
        if (self::ownsCurrentRequest()) {
            $classes[] = 'vdm-site-shell';
        }
        return array_values(array_unique($classes));
    }

    /**
     * True shell ownership is deliberately narrow: only singular WordPress
     * pages carrying canonical VDM layout data can bypass the active theme's
     * page template. Ordinary WordPress pages remain theme-owned.
     */
    public static function ownsCurrentRequest(): bool
    {
        if (is_admin() || !self::enabled() || !is_singular('page')) {
            return false;
        }
        $postId = (int) get_queried_object_id();
        return $postId > 0 && metadata_exists('post', $postId, LayoutModel::META);
    }

    /**
     * Replace the theme template, not its styles or WordPress lifecycle hooks.
     * The standalone VDM template still calls wp_head(), wp_body_open() and
     * wp_footer(), but never get_header()/get_footer()/the_title().
     */
    public static function templateInclude(string $template): string
    {
        if (!self::ownsCurrentRequest()) {
            return $template;
        }
        $standalone = VDM_DIR . 'templates/vdm-site-shell.php';
        return is_readable($standalone) ? $standalone : $template;
    }

    public static function resolvedTemplateId(int $postId, string $part): string
    {
        $part = sanitize_key($part) === 'footer' ? 'footer' : 'header';
        if ($postId <= 0) {
            return '';
        }
        TemplateLayoutModel::ensureMigrated();
        return TemplateLayoutModel::resolveId($postId, $part);
    }

    /** @return array{enabled:bool,header:string,footer:string} */
    public static function status(int $postId): array
    {
        return [
            'enabled' => self::enabled(),
            'header' => self::resolvedTemplateId($postId, 'header'),
            'footer' => self::resolvedTemplateId($postId, 'footer'),
        ];
    }

    private function __construct()
    {
    }
}
