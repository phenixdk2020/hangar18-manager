<?php

declare(strict_types=1);

namespace VisualDesignerManager\Migration;

use VisualDesignerManager\Model\LayoutModel;

final class V3DetailLayoutRepair
{
    private const EVENT_META = '_vdm_v3_alpha9_event_detail_repaired';
    private const EVENT_BACKUP = '_vdm_v3_alpha9_event_detail_backup';
    private const ALBUM_META = '_vdm_v3_alpha9_album_detail_repaired';

    public static function register(): void
    {
        add_action('admin_init', [self::class, 'ensure'], 35);
    }

    public static function ensure(): void
    {
        if (!current_user_can('edit_pages')) { return; }
        self::repairEvent();
        self::repairAlbum();
    }

    private static function repairEvent(): void
    {
        $page = get_page_by_path('event-detalje', OBJECT, 'page');
        if (!$page instanceof \WP_Post) { return; }
        $postId = (int) $page->ID;
        if (get_post_meta($postId, self::EVENT_META, true)) { return; }
        $model = LayoutModel::get($postId);
        $nodes = isset($model['nodes']) && is_array($model['nodes']) ? array_values($model['nodes']) : [];
        $ids = [];
        foreach ($nodes as $node) { if (is_array($node)) { $ids[(string) ($node['id'] ?? '')] = true; } }
        $known = ['detail-section','event-image','event-facts','eventfield-about','eventfield-program','eventfield-practical'];
        foreach ($known as $id) {
            if (empty($ids[$id])) {
                update_post_meta($postId, self::EVENT_META, ['status'=>'skipped-custom-layout','checkedUtc'=>gmdate('c')]);
                return;
            }
        }
        update_post_meta($postId, self::EVENT_BACKUP, $model);
        $drop = ['event-title'=>true,'event-date'=>true,'event-location'=>true,'event-summary'=>true,'event-description'=>true];
        $positions = [
            'detail-back'=>[3,2,30,7,10],
            'event-image'=>[3,10,114,44,20],
            'event-facts'=>[3,56,114,10,30],
            'eventfield-about'=>[3,68,114,12,40],
            'eventfield-program'=>[3,82,114,12,50],
            'eventfield-practical'=>[3,96,114,12,60],
        ];
        $next = [];
        foreach ($nodes as $node) {
            if (!is_array($node)) { continue; }
            $id = (string) ($node['id'] ?? '');
            if (isset($drop[$id])) { continue; }
            if ($id === 'detail-section') {
                $node['geometry'] = self::geometry(0,0,120,112);
                $node['props'] = is_array($node['props'] ?? null) ? $node['props'] : [];
                $node['props']['minHeightRows'] = 112;
                if (!array_key_exists('paddingBottom', $node['props'])) { $node['props']['paddingBottom'] = 32; }
            } elseif (isset($positions[$id])) {
                [$x,$y,$w,$h,$order] = $positions[$id];
                $node['geometry'] = self::geometry($x,$y,$w,$h);
                $node['order'] = $order;
                $node['parentId'] = 'detail-section';
            }
            $next[] = $node;
        }
        $model['nodes'] = $next;
        $version = LayoutModel::saveVersion($postId, $model, get_current_user_id(), 'V3 alpha.9: gendan oprindelig Eventdetalje-rækkefølge');
        update_post_meta($postId, self::EVENT_META, ['status'=>'repaired','version'=>$version,'repairedUtc'=>gmdate('c')]);
    }

    private static function repairAlbum(): void
    {
        $page = get_page_by_path('album-detalje', OBJECT, 'page');
        if (!$page instanceof \WP_Post) { return; }
        $postId = (int) $page->ID;
        if (get_post_meta($postId, self::ALBUM_META, true)) { return; }
        $model = LayoutModel::get($postId);
        $nodes = isset($model['nodes']) && is_array($model['nodes']) ? array_values($model['nodes']) : [];
        $changed = false;
        foreach ($nodes as &$node) {
            if (!is_array($node)) { continue; }
            $id = (string) ($node['id'] ?? '');
            if ($id === 'detail-back' && (string) ($node['type'] ?? '') === 'button') {
                $node['props'] = is_array($node['props'] ?? null) ? $node['props'] : [];
                $node['props']['text'] = '← Tilbage til album';
                $changed = true;
            }
            if ($id === 'detail-section' && (string) ($node['type'] ?? '') === 'section') {
                $node['props'] = is_array($node['props'] ?? null) ? $node['props'] : [];
                if (!array_key_exists('paddingBottom', $node['props'])) { $node['props']['paddingBottom'] = 48; }
                $changed = true;
            }
        }
        unset($node);
        if (!$changed) {
            update_post_meta($postId, self::ALBUM_META, ['status'=>'skipped-custom-layout','checkedUtc'=>gmdate('c')]);
            return;
        }
        $model['nodes'] = $nodes;
        $version = LayoutModel::saveVersion($postId, $model, get_current_user_id(), 'V3 alpha.9: album tilbage-link + styrbar bundluft');
        update_post_meta($postId, self::ALBUM_META, ['status'=>'repaired','version'=>$version,'repairedUtc'=>gmdate('c')]);
    }

    /** @return array<string,mixed> */
    private static function geometry(int $x, int $y, int $w, int $h): array
    {
        return [
            'desktop'=>['x'=>$x,'y'=>$y,'w'=>$w,'h'=>$h],
            'laptop'=>['x'=>$x,'y'=>$y,'w'=>$w,'h'=>$h,'inheritDesktop'=>true],
            'tablet'=>['x'=>$x,'y'=>$y,'w'=>$w,'h'=>$h,'inheritDesktop'=>true],
            'mobile'=>['x'=>0,'y'=>$y,'w'=>120,'h'=>$h,'inheritDesktop'=>false],
        ];
    }

    private function __construct() {}
}
