<?php

declare(strict_types=1);

namespace VisualDesignerManager\Migration;

use VisualDesignerManager\Model\LayoutModel;

final class ResponsivePaintUnifier
{
    private const VERSION = '3.0.0-alpha.27';
    private const DONE_META = '_vdm_alpha27_responsive_paint_unified_v1';
    private const BACKUP_META = '_vdm_alpha27_responsive_paint_backup_v1';
    private const LEGACY_META = '_h18_clean_layout_v1';
    private const OLIVE = '#30382a';
    private const SAND = '#c3ae83';

    public static function register(): void
    {
        add_action('init', [self::class, 'run'], 7);
    }

    public static function run(): void
    {
        global $wpdb;
        $postIds = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s ORDER BY post_id",
            self::LEGACY_META
        ));
        foreach ((array) $postIds as $postIdRaw) {
            $postId = (int) $postIdRaw;
            if ($postId <= 0 || get_post_type($postId) !== 'page') { continue; }
            if ((string) get_post_meta($postId, self::DONE_META, true) === self::VERSION) { continue; }
            if (!metadata_exists('post', $postId, LayoutModel::META)) { continue; }
            $before = LayoutModel::get($postId);
            $after = self::unifyModel($before);
            if (LayoutModel::structuralDigest($after) !== LayoutModel::structuralDigest($before)) {
                if (!metadata_exists('post', $postId, self::BACKUP_META)) {
                    add_post_meta($postId, self::BACKUP_META, [
                        'version' => self::VERSION,
                        'savedUtc' => gmdate('c'),
                        'model' => $before,
                    ], true);
                }
                LayoutModel::saveVersion($postId, $after, 0, 'Alpha.27: fælles responsive farver og kasser');
            }
            update_post_meta($postId, self::DONE_META, self::VERSION);
        }
    }

    /** @param array<string,mixed> $model @return array<string,mixed> */
    public static function unifyModel(array $model): array
    {
        $nodes = isset($model['nodes']) && is_array($model['nodes']) ? $model['nodes'] : [];
        $byId = [];
        foreach ($nodes as $index => $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $byId[(string) $node['id']] = $index;
        }

        $taglineId = '';
        $heroId = '';
        $heroY = PHP_INT_MAX;
        foreach ($nodes as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $type = (string) ($node['type'] ?? '');
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $heading = strtolower(trim(wp_strip_all_tags((string) ($props['heading'] ?? ''))));
            $text = strtolower(trim(wp_strip_all_tags((string) ($props['text'] ?? ''))));
            $hay = $heading . ' ' . $text;
            if ($type === 'text' && str_contains($hay, 'bevaring, restaurering og levende') && str_contains($hay, 'militærhistorie')) {
                $taglineId = $id;
            }
            if ($type === 'image') {
                $geometry = isset($node['geometry']['desktop']) && is_array($node['geometry']['desktop']) ? $node['geometry']['desktop'] : [];
                $w = (int) ($geometry['w'] ?? 0);
                $y = (int) ($geometry['y'] ?? PHP_INT_MAX);
                if ($w >= 100 && $y < $heroY) { $heroId = $id; $heroY = $y; }
            }
        }

        $nearestSection = static function (string $id) use (&$nodes, $byId): string {
            $guard = 0;
            $current = $id;
            while ($current !== '' && isset($byId[$current]) && $guard++ < 32) {
                $node = $nodes[$byId[$current]];
                $parent = (string) ($node['parentId'] ?? '');
                if ($parent === '' || !isset($byId[$parent])) { return ''; }
                $parentNode = $nodes[$byId[$parent]];
                if ((string) ($parentNode['type'] ?? '') === 'section') { return $parent; }
                $current = $parent;
            }
            return '';
        };

        $paintSection = static function (string $id, string $color) use (&$nodes, $byId): void {
            if ($id === '' || !isset($byId[$id])) { return; }
            $index = $byId[$id];
            $props = is_array($nodes[$index]['props'] ?? null) ? $nodes[$index]['props'] : [];
            $props['background'] = $color;
            $props['backgroundTransparent'] = false;
            $nodes[$index]['props'] = $props;
        };

        $heroSection = $taglineId !== '' ? $nearestSection($heroId) : '';
        $taglineSection = $nearestSection($taglineId);
        if ($taglineId !== '') {
            $paintSection($heroSection, self::OLIVE);
            $paintSection($taglineSection, self::SAND);
        }

        if ($taglineId !== '' && isset($byId[$taglineId])) {
            $index = $byId[$taglineId];
            $props = is_array($nodes[$index]['props'] ?? null) ? $nodes[$index]['props'] : [];
            $props['background'] = self::SAND;
            $props['backgroundTransparent'] = true;
            $props['textColor'] = self::OLIVE;
            $props['headingColor'] = self::OLIVE;
            $nodes[$index]['props'] = $props;
        }

        $model['nodes'] = $nodes;
        return $model;
    }

    private function __construct() {}
}
