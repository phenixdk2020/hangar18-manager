<?php

declare(strict_types=1);

namespace VisualDesignerManager\Compatibility;

/**
 * Temporary V3 compatibility layer for pre-Alpha.4 WordPress admin URLs.
 *
 * Canonical runtime links use vdm-* page slugs. Historical h18-clean-* URLs
 * remain accepted as redirects only so bookmarks and old diagnostic links do
 * not break during the staged V3 cutover.
 */
final class AdminRouteCompatibility
{
    /** @var array<string,string> */
    private const LEGACY_TO_CANONICAL = [
        'h18-clean-manager' => 'vdm-manager',
        'h18-clean-editor' => 'vdm-editor',
        'h18-clean-vehicles' => 'vdm-vehicles',
        'h18-clean-vehicle-fields' => 'vdm-vehicle-fields',
        'h18-clean-events' => 'vdm-events',
        'h18-clean-event-fields' => 'vdm-event-fields',
        'h18-clean-gallery' => 'vdm-gallery',
        'h18-clean-data' => 'vdm-data',
        'h18-clean-pages' => 'vdm-pages',
        'h18-clean-conversion' => 'vdm-conversion',
        'h18-clean-menu' => 'vdm-menu',
        'h18-clean-header-footer' => 'vdm-header-footer',
        'h18-clean-backup' => 'vdm-backup',
        'h18-clean-updates' => 'vdm-updates',
        'h18-clean-log' => 'vdm-log',
        'h18-clean-manual' => 'vdm-manual',
        'h18-clean-export' => 'vdm-export',
        'h18-clean-theme' => 'vdm-theme',
    ];

    public static function register(): void
    {
        add_action('admin_init', [self::class, 'redirectLegacyRoute'], 0);
    }

    public static function redirectLegacyRoute(): void
    {
        global $pagenow;
        if (!is_admin() || $pagenow !== 'admin.php') {
            return;
        }

        $legacy = sanitize_key((string) wp_unslash($_GET['page'] ?? ''));
        $canonical = self::LEGACY_TO_CANONICAL[$legacy] ?? '';
        if ($canonical === '') {
            return;
        }

        $args = ['page' => $canonical];
        foreach ($_GET as $key => $value) {
            if ((string) $key === 'page' || !is_scalar($value)) {
                continue;
            }
            $cleanKey = sanitize_key((string) $key);
            if ($cleanKey === '') {
                continue;
            }
            $args[$cleanKey] = sanitize_text_field((string) wp_unslash((string) $value));
        }

        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')), 302, 'Visual Designer Manager V3');
        exit;
    }

    public static function canonical(string $legacy): string
    {
        $legacy = sanitize_key($legacy);
        return self::LEGACY_TO_CANONICAL[$legacy] ?? $legacy;
    }

    private function __construct() {}
}
