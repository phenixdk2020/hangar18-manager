(function () {
    'use strict';

    /*
     * Status rule:
     * ready   = the agreed backlog / Definition of Done for this module is complete.
     * partial = usable work exists, but the agreed module scope is not complete.
     * planned = placeholder / not yet implemented to a usable level.
     */
    var STATUS = {
        'vdm-manager': ['Under udvikling', 'partial'],
        'vdm-editor': ['Under udvikling', 'partial'],
        'vdm-pages': ['Klar', 'ready'],
        'vdm-conversion': ['Klar', 'ready'],
        'vdm-backup': ['Under udvikling', 'partial'],
        'vdm-updates': ['Klar', 'ready'],
        'vdm-log': ['Klar', 'ready'],
        'vdm-export': ['Under udvikling', 'partial'],
        'vdm-menu': ['Klar', 'ready'],
        'vdm-theme': ['Under udvikling', 'partial'],
        'vdm-header-footer': ['Klar', 'ready'],
        'vdm-vehicles': ['Klar', 'ready'],
        'vdm-vehicle-fields': ['Klar', 'ready'],
        'vdm-events': ['Klar', 'ready'],
        'vdm-event-fields': ['Klar', 'ready'],
        'vdm-gallery': ['Klar', 'ready'],
        'vdm-manual': ['Klar', 'ready'],
        'vdm-data': ['Ikke færdig', 'planned']
    };

    function pageFromHref(href) {
        try { return new URL(href, window.location.href).searchParams.get('page') || ''; }
        catch (ignore) { return ''; }
    }

    function badge(label, state) {
        var span = document.createElement('span');
        span.className = 'vd-manager-status vd-manager-status--' + state;
        span.textContent = label;
        span.title = label;
        return span;
    }

    function addMenuStatuses() {
        var root = document.getElementById('toplevel_page_vdm-manager');
        if (!root) { return; }
        root.querySelectorAll('.wp-submenu a[href]').forEach(function (link) {
            var page = pageFromHref(link.href);
            var info = STATUS[page];
            if (!info || link.querySelector('.vd-manager-status')) { return; }
            link.appendChild(badge(info[0], info[1]));
        });
    }

    function addDashboardLegend() {
        if (pageFromHref(window.location.href) !== 'vdm-manager') { return; }
        var hero = document.querySelector('.h18-manager-hero');
        if (!hero || document.querySelector('.vd-manager-status-legend')) { return; }
        var legend = document.createElement('div');
        legend.className = 'vd-manager-status-legend';
        legend.innerHTML = '<strong>Modulstatus:</strong> <span class="vd-manager-status vd-manager-status--ready">Klar</span> <span class="vd-manager-status vd-manager-status--partial">Under udvikling</span> <span class="vd-manager-status vd-manager-status--planned">Ikke færdig</span>';
        hero.insertAdjacentElement('afterend', legend);
    }

    function install() {
        addMenuStatuses();
        addDashboardLegend();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', install, { once: true });
    } else {
        install();
    }
}());
