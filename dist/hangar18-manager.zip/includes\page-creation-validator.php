<?php

final class Hangar18_PageCreationValidator {
    public static function normalize_template_key($template) {
        $value = trim((string) $template);
        if ($value === '') {
            return 'blank';
        }

        return $value;
    }

    public static function slugify($value) {
        $input = strtolower(trim((string) $value));
        $map = [
            'æ' => 'ae', 'ø' => 'oe', 'å' => 'aa',
            'ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue',
            'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a',
            'í' => 'i', 'ì' => 'i', 'î' => 'i',
            'ó' => 'o', 'ò' => 'o', 'ô' => 'o',
            'ú' => 'u', 'ù' => 'u', 'û' => 'u',
            'ç' => 'c', 'ñ' => 'n', 'ß' => 'ss',
        ];
        $input = strtr($input, $map);
        $input = preg_replace('/[^a-z0-9]+/', '-', $input);
        $input = trim((string) $input, '-');

        return $input === '' ? 'side' : $input;
    }

    public static function normalize_page_creation_payload(
        $page_slug,
        $page_name,
        $page_title,
        $template,
        array $existing_page_paths = [],
        array $allowed_templates = ['blank', 'default']
    ) {
        $base_slug = self::slugify($page_slug !== '' ? $page_slug : $page_name);
        $slug = $base_slug;
        $slug_changed = false;
        $counter = 1;

        $normalized_existing = [];
        foreach ($existing_page_paths as $existing_path) {
            $normalized_existing[] = self::slugify((string) $existing_path);
        }

        while (in_array($slug, $normalized_existing, true)) {
            $slug_changed = true;
            $slug = $base_slug . '-' . $counter;
            $counter++;
        }

        $title = trim((string) ($page_title !== '' ? $page_title : str_replace('-', ' ', $slug)));
        if ($title === '') {
            $title = ucwords(str_replace('-', ' ', $slug));
        }

        $template_key = self::normalize_template_key($template);
        $allowed = [];
        foreach ($allowed_templates as $allowed_template) {
            $normalized = self::normalize_template_key($allowed_template);
            if ($normalized !== '' && !in_array($normalized, $allowed, true)) {
                $allowed[] = $normalized;
            }
        }
        if (!in_array($template_key, $allowed, true)) {
            $template_key = 'blank';
        }

        return [
            'slug' => $slug,
            'title' => $title,
            'template' => $template_key,
            'slug_changed' => $slug_changed,
        ];
    }
}
