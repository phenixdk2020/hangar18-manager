<?php

declare(strict_types=1);

namespace Hangar18\UltimateDesigner\Admin;

/**
 * Browser-local preview of the current unsaved Sider editor state.
 *
 * The preview clones the already rendered admin canvas. It has no AJAX,
 * admin-post handler, option/post mutation or public renderer hook.
 */
final class EditorUnsavedPreviewAdminController
{
    private static bool $registered = false;

    public static function register(): void
    {
        if (self::$registered) {
            return;
        }
        self::$registered = true;
        add_action('admin_enqueue_scripts', [self::class, 'enqueue']);
    }

    public static function enqueue(): void
    {
        $page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
        if ($page !== 'hangar18-pages' || !current_user_can('edit_pages')) {
            return;
        }

        $pluginDir = dirname(__DIR__, 2);
        $pluginUrl = plugin_dir_url($pluginDir . '/hangar18-manager.php');
        $jsPath = $pluginDir . '/assets/ultimate-designer-unsaved-preview.js';
        $cssPath = $pluginDir . '/assets/ultimate-designer-unsaved-preview.css';

        wp_enqueue_script(
            'hangar18-ultimate-designer-unsaved-preview',
            $pluginUrl . 'assets/ultimate-designer-unsaved-preview.js',
            ['jquery', 'hangar18-manager-admin'],
            is_file($jsPath) ? (string) filemtime($jsPath) : '0.8.25',
            true
        );
        wp_enqueue_style(
            'hangar18-ultimate-designer-unsaved-preview',
            $pluginUrl . 'assets/ultimate-designer-unsaved-preview.css',
            [],
            is_file($cssPath) ? (string) filemtime($cssPath) : '0.8.25'
        );
    }
}
