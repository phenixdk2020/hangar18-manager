<?php

declare(strict_types=1);

namespace VisualDesignerManager\Frontend;

use VisualDesignerManager\Model\LayoutModel;
use VisualDesignerManager\Model\TemplateLayoutModel;
use VisualDesignerManager\Modules\ModuleStore;

/**
 * Responsive geometry layer for Clean Designer.
 *
 * The normal Renderer remains the single HTML renderer. This class only emits
 * breakpoint-specific geometry overrides from the same canonical model.
 */
final class ResponsiveRenderer
{
    public const LAPTOP_MAX = 1180;
    public const TABLET_MAX = 980;
    public const MOBILE_MAX = 782;

    public static function register(): void
    {
        add_action('wp_head', [self::class, 'css'], 1001);
    }

    public static function css(): void
    {
        if (!is_singular('page')) {
            return;
        }

        $postId = get_queried_object_id();
        if ($postId <= 0) {
            return;
        }

        $pageModel = self::model($postId);
        if ($pageModel === null || empty($pageModel['nodes']) || !is_array($pageModel['nodes'])) {
            return;
        }

        $pageScope = ThemeShell::enabled() ? '.h18-vd-live-shell-page ' : '';
        $models = [[
            'scope' => $pageScope,
            'model' => $pageModel,
        ]];
        // Converted V1 pages use V1's natural one-column mobile flow contract.
        // New V3-native pages keep the explicit responsive grid model.
        $v1MobileFlow = metadata_exists('post', $postId, '_h18_clean_layout_v1')
            ? self::v1MobileFlowCss($pageModel, $pageScope)
            : '';

        if (ThemeShell::enabled()) {
            foreach (['header', 'footer'] as $part) {
                $templateId = ThemeShell::resolvedTemplateId($postId, $part);
                if ($templateId === '' || !TemplateLayoutModel::exists($templateId, $part)) {
                    continue;
                }
                $templateModel = TemplateLayoutModel::model($templateId);
                if (empty($templateModel['nodes']) || !is_array($templateModel['nodes'])) {
                    continue;
                }
                $models[] = [
                    'scope' => $part === 'header' ? '.h18-vd-live-shell-header ' : '.h18-vd-live-shell-footer ',
                    'model' => $templateModel,
                ];
            }
        }

        $laptop = '';
        $tablet = '';
        $mobile = '';
        foreach ($models as $entry) {
            self::appendModelCss(
                (array) ($entry['model'] ?? []),
                (string) ($entry['scope'] ?? ''),
                $laptop,
                $tablet,
                $mobile
            );
        }

        echo '<style id="h18-clean-responsive-css">';
        echo '.h18-clean-page{max-width:100%;overflow-x:clip}';
        echo '.h18-vd-live-shell,.h18-vd-live-shell-part,.h18-vd-live-shell-part>.h18-clean-page{width:100%;max-width:100%;min-width:0;box-sizing:border-box}';
        echo '@media(max-width:' . esc_attr((string) self::LAPTOP_MAX) . 'px){' . $laptop . '}';
        echo '@media(max-width:' . esc_attr((string) self::TABLET_MAX) . 'px){' . $tablet . '}';
        echo '@media(max-width:' . esc_attr((string) self::MOBILE_MAX) . 'px){'
            . '.h18-vd-live-shell,.h18-vd-live-shell-part,.h18-clean-page,.h18-clean-front-section,.h18-clean-front-container{min-width:0;max-width:100%;}'
            . '.h18-vd-live-shell{overflow-x:hidden;}'
            . $mobile
            . $v1MobileFlow . '}';
        echo '</style>';
    }

    /**
     * Emit the same responsive geometry contract for one rendered model.
     * Header, page and Footer models are scoped independently so identical
     * node IDs in different parts cannot overwrite one another.
     *
     * @param array<string,mixed> $model
     */
    private static function appendModelCss(array $model, string $scope, string &$laptop, string &$tablet, string &$mobile): void
    {
        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) {
                continue;
            }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $parent = (string) ($node['parentId'] ?? '');
            $byParent[$parent][] = $node;
        }

        foreach ($byId as $id => $node) {
            $lg = self::effectiveGeometry($node, 'laptop');
            $tg = self::effectiveGeometry($node, 'tablet');
            $mg = self::effectiveGeometry($node, 'mobile');
            $laptopRows = self::effectiveRows($id, 'laptop', $byId, $byParent, []);
            $tabletRows = self::effectiveRows($id, 'tablet', $byId, $byParent, []);
            $mobileRows = self::effectiveRows($id, 'mobile', $byId, $byParent, []);
            $selector = $scope . '#h18-clean-' . self::cssId($id);
            $props = is_array($node['props'] ?? null) ? $node['props'] : [];
            $floating = (string) ($node['type'] ?? '') === 'button' && (string) ($props['placementMode'] ?? 'normal') === 'overlay';
            $zIndex = max(1, min(200, (int) ($props['zIndex'] ?? 20)));
            $laptop .= self::geometryCss($selector, $lg, $laptopRows, $floating, $zIndex);
            $tablet .= self::geometryCss($selector, $tg, $tabletRows, $floating, $zIndex);
            $mobile .= self::geometryCss($selector, $mg, $mobileRows, $floating, $zIndex);
        }
    }

    /**
     * Recreate the mobile flow semantics used by the working V1 page runtime.
     * V1 does not keep desktop-style columns on phones: content sections stack,
     * text/image compositions become one column and direct children follow the
     * visual mobile y/x order. This is intentionally page-only; Header/Footer
     * retain their independent responsive template geometry.
     *
     * @param array<string,mixed> $model
     */
    private static function v1MobileFlowCss(array $model, string $scope): string
    {
        $byId = [];
        $byParent = [];
        foreach ((array) ($model['nodes'] ?? []) as $node) {
            if (!is_array($node) || empty($node['id'])) { continue; }
            $id = (string) $node['id'];
            $byId[$id] = $node;
            $parent = (string) ($node['parentId'] ?? '');
            $byParent[$parent][] = $node;
        }

        $surface = $scope . '.h18-clean-front-surface';
        $section = $scope . '.h18-clean-front-section';
        $container = $scope . '.h18-clean-front-container';
        $css = $surface . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;overflow:visible!important;}'
            . $section . ',' . $container . '{display:flex!important;flex-direction:column!important;align-items:stretch!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;overflow:visible!important;box-sizing:border-box!important;padding-top:min(var(--h18-vdm-pad-top,0px),38px)!important;padding-right:min(var(--h18-vdm-pad-right,0px),18px)!important;padding-bottom:min(var(--h18-vdm-pad-bottom,0px),38px)!important;padding-left:min(var(--h18-vdm-pad-left,0px),18px)!important;}'
            . $scope . '.h18-clean-front-event-list,' . $scope . '.h18-clean-front-gallery-list,' . $scope . '.h18-clean-front-gallery-images,' . $scope . '.h18-clean-front-event-facts{grid-template-columns:1fr!important;width:100%!important;max-width:100%!important;}'
            . $scope . '.h18-clean-front-event-detail,' . $scope . '.h18-clean-front-gallery-detail,' . $scope . '.h18-clean-front-event-image{width:100%!important;max-width:100%!important;justify-self:stretch!important;box-sizing:border-box!important;}'
            . $scope . '.h18-clean-front-gallery-images img{width:100%!important;height:auto!important;aspect-ratio:4/3;object-fit:cover!important;}'
            . $scope . '.h18-clean-front-event-list img,' . $scope . '.h18-clean-front-gallery-list img{width:100%!important;height:auto!important;aspect-ratio:16/10;object-fit:cover!important;}'
            . $scope . '.h18-clean-front-spacer{height:24px!important;min-height:24px!important;flex:0 0 24px!important;}';

        foreach ($byParent as $children) {
            usort($children, static function (array $a, array $b): int {
                $ag = self::effectiveGeometry($a, 'mobile');
                $bg = self::effectiveGeometry($b, 'mobile');
                return ($ag['y'] <=> $bg['y'])
                    ?: ($ag['x'] <=> $bg['x'])
                    ?: ((int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0));
            });

            $previousBottom = 0;
            foreach (array_values($children) as $index => $node) {
                $id = (string) ($node['id'] ?? '');
                if ($id === '') { continue; }
                $g = self::effectiveGeometry($node, 'mobile');
                $rows = self::effectiveRows($id, 'mobile', $byId, $byParent, []);
                $gapRows = $index === 0 ? 0 : max(0, $g['y'] - $previousBottom);
                $gapPx = min(24, $gapRows * LayoutModel::ROW_PX);
                $selector = $scope . '#h18-clean-' . self::cssId($id);
                $type = (string) ($node['type'] ?? '');
                $props = is_array($node['props'] ?? null) ? $node['props'] : [];
                $floating = $type === 'button' && (string) ($props['placementMode'] ?? 'normal') === 'overlay';

                $css .= $selector . '{order:' . $index . '!important;grid-column:auto!important;grid-row:auto!important;position:relative!important;left:auto!important;right:auto!important;top:auto!important;width:100%!important;max-width:100%!important;height:auto!important;margin-top:' . $gapPx . 'px!important;margin-right:0!important;margin-bottom:min(var(--h18-vdm-gap-y,0px),24px)!important;box-sizing:border-box!important;transform:none!important;}';
                if (!in_array($type, ['image', 'eventimage', 'spacer'], true)) {
                    $css .= $selector . '{min-height:0!important;}';
                }
                if ($floating) {
                    $css .= $selector . '{z-index:auto!important;}';
                }
                $previousBottom = max($previousBottom, $g['y'] + $rows);
            }
        }
        return $css;
    }

    /** @return array<string,mixed>|null */
    private static function model(int $postId): ?array
    {
        $preview = self::previewModel($postId);
        if ($preview !== null) {
            return $preview;
        }
        if (!metadata_exists('post', $postId, LayoutModel::META)) {
            return null;
        }
        return LayoutModel::get($postId);
    }

    /** @return array<string,mixed>|null */
    private static function previewModel(int $postId): ?array
    {
        if (!is_user_logged_in() || !current_user_can('edit_pages')) {
            return null;
        }
        $token = isset($_GET['h18_clean_preview']) ? sanitize_key((string) wp_unslash($_GET['h18_clean_preview'])) : '';
        if ($token === '' || !preg_match('/^[a-z0-9]{12,64}$/', $token)) {
            return null;
        }
        $raw = get_transient(Renderer::previewKey(get_current_user_id(), $postId, $token));
        if (!is_array($raw)) {
            return null;
        }
        try {
            return LayoutModel::normalize($raw);
        } catch (\Throwable $error) {
            return null;
        }
    }

    /** @param array<string,mixed> $node @return array{x:int,y:int,w:int,h:int} */
    private static function effectiveGeometry(array $node, string $device): array
    {
        $geometry = is_array($node['geometry'] ?? null) ? $node['geometry'] : [];
        $desktop = self::geometry($geometry['desktop'] ?? null);
        if ($device === 'desktop') {
            return $desktop;
        }

        $laptopRaw = is_array($geometry['laptop'] ?? null) ? $geometry['laptop'] : [];
        $laptop = !empty($laptopRaw['inheritDesktop']) ? $desktop : self::geometry($laptopRaw, $desktop);
        if ($device === 'laptop') {
            return $laptop;
        }

        $tabletRaw = is_array($geometry['tablet'] ?? null) ? $geometry['tablet'] : [];
        $tablet = !empty($tabletRaw['inheritDesktop']) ? $laptop : self::geometry($tabletRaw, $laptop);
        if ($device === 'tablet') {
            return $tablet;
        }

        $mobileRaw = is_array($geometry['mobile'] ?? null) ? $geometry['mobile'] : [];
        // Responsive inheritance is cascading: Mobile inherits Tablet, Tablet
        // inherits Laptop, and Laptop may inherit Desktop.
        return !empty($mobileRaw['inheritDesktop']) ? $tablet : self::geometry($mobileRaw, $tablet);
    }

    /** @param mixed $raw @param array{x:int,y:int,w:int,h:int}|null $fallback @return array{x:int,y:int,w:int,h:int} */
    private static function geometry(mixed $raw, ?array $fallback = null): array
    {
        $fallback ??= ['x' => 0, 'y' => 0, 'w' => LayoutModel::UNITS, 'h' => 0];
        if (!is_array($raw)) {
            return $fallback;
        }
        $x = max(0, min(LayoutModel::UNITS - 1, (int) ($raw['x'] ?? $fallback['x'])));
        $w = max(1, min(LayoutModel::UNITS - $x, (int) ($raw['w'] ?? $fallback['w'])));
        return [
            'x' => $x,
            'y' => max(0, min(10000, (int) ($raw['y'] ?? $fallback['y']))),
            'w' => $w,
            'h' => max(0, min(4000, (int) ($raw['h'] ?? $fallback['h']))),
        ];
    }

    /**
     * Runtime auto-grow for a breakpoint. This is deliberately derived from
     * canonical child geometry so responsive parents cannot visually overlap
     * following siblings merely because their children were stacked on Mobile.
     *
     * @param array<string,array<string,mixed>> $byId
     * @param array<string,array<int,array<string,mixed>>> $byParent
     * @param array<string,bool> $seen
     */
    private static function effectiveRows(string $id, string $device, array $byId, array $byParent, array $seen): int
    {
        if (!isset($byId[$id]) || isset($seen[$id])) {
            return 1;
        }
        $seen[$id] = true;
        $node = $byId[$id];
        $g = self::effectiveGeometry($node, $device);
        $type = (string) ($node['type'] ?? '');
        $base = $g['h'] > 0 ? $g['h'] : (in_array($type, ['text', 'image'], true) ? 10 : 8);
        if ($type === 'gallerydetail') { $base = max($base, self::galleryDetailRows($node, $device)); }
        if ($type === 'eventfacts' && $device === 'mobile') { $base = max($base, 42); }

        if (!in_array($type, ['section', 'container'], true)) {
            return max(1, $base);
        }

        $required = 0;
        foreach ($byParent[$id] ?? [] as $child) {
            $childProps = is_array($child['props'] ?? null) ? $child['props'] : [];
            if ((string) ($child['type'] ?? '') === 'button' && (string) ($child['parentId'] ?? '') !== '' && (string) ($childProps['placementMode'] ?? 'normal') === 'overlay') { continue; }
            $childId = (string) ($child['id'] ?? '');
            if ($childId === '') {
                continue;
            }
            $cg = self::effectiveGeometry($child, $device);
            $required = max($required, $cg['y'] + self::effectiveRows($childId, $device, $byId, $byParent, $seen));
        }

        $props = is_array($node['props'] ?? null) ? $node['props'] : [];
        $legacyPadding = max(0, (int) ($props['padding'] ?? 0));
        $paddingTop = max(0, (int) ($props['paddingTop'] ?? $legacyPadding));
        $paddingBottom = max(0, (int) ($props['paddingBottom'] ?? $legacyPadding));
        $extraPx = $paddingTop + $paddingBottom + (max(0, (int) ($props['borderWidth'] ?? 0)) * 2);
        $required += (int) ceil($extraPx / LayoutModel::ROW_PX);
        return max(1, $base, $required);
    }

    /** @param array<string,mixed> $node */
    private static function galleryDetailRows(array $node, string $device): int
    {
        $props = is_array($node['props'] ?? null) ? $node['props'] : [];
        $recordId = strtolower(trim((string) ($props['recordId'] ?? '')));
        if ($recordId === '') { $recordId = strtolower(trim(sanitize_text_field((string) wp_unslash($_GET['h18_gallery'] ?? '')))); }
        $count = 0; $hasDescription = false;
        if ($recordId !== '' && preg_match('/^[a-z0-9][a-z0-9._:-]{0,127}$/', $recordId)) {
            $found = ModuleStore::findByRecordId('galleries', $recordId);
            $record = is_array($found) && isset($found['record']) && is_array($found['record']) ? $found['record'] : null;
            if (is_array($record)) {
                $fields = isset($record['fields']) && is_array($record['fields']) ? $record['fields'] : [];
                $ids = isset($fields['imageIds']) && is_array($fields['imageIds']) ? array_values(array_filter(array_map('absint', $fields['imageIds']))) : [];
                $count = count($ids);
                $hasDescription = !empty($props['showDescription']) && trim((string) ($fields['description'] ?? '')) !== '';
            }
        }
        $columns = $device === 'mobile' ? 1 : ($device === 'tablet' ? min(2, max(1, (int) ($props['columns'] ?? 4))) : max(1, min(6, (int) ($props['columns'] ?? 4))));
        $imageHeight = max(80, min(700, (int) ($props['imageHeight'] ?? 220)));
        $gap = max(0, min(80, (int) ($props['gap'] ?? 12)));
        $padding = max(0, min(80, (int) ($props['padding'] ?? 16)));
        $imageRows = $count > 0 ? (int) ceil($count / $columns) : 0;
        $px = 88 + ($hasDescription ? 144 : 0) + ($padding * 2);
        if ($imageRows > 0) { $px += ($imageRows * $imageHeight) + (max(0, $imageRows - 1) * $gap); }
        return max(8, (int) ceil($px / LayoutModel::ROW_PX));
    }

    /** @param array{x:int,y:int,w:int,h:int} $g */
    private static function geometryCss(string $selector, array $g, int $rows, bool $floating = false, int $zIndex = 20): string
    {
        $rows = max(1, $rows);
        if ($floating) {
            $left = ($g['x'] / LayoutModel::UNITS) * 100;
            $width = ($g['w'] / LayoutModel::UNITS) * 100;
            return $selector . '{position:absolute!important;left:' . $left . '%!important;top:' . (max(0, $g['y']) * LayoutModel::ROW_PX) . 'px!important;'
                . 'width:' . $width . '%!important;height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;min-height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;'
                . 'z-index:' . max(1, min(200, $zIndex)) . '!important;grid-column:auto!important;grid-row:auto!important;margin-top:0!important;}';
        }
        $row = max(0, $g['y']) + 1;
        return $selector . '{grid-column:' . ($g['x'] + 1) . '/span ' . $g['w'] . '!important;'
            . 'grid-row:' . $row . '/span ' . $rows . '!important;'
            . 'min-height:' . ($rows * LayoutModel::ROW_PX) . 'px!important;'
            . 'margin-top:0!important;}';
    }

    private static function cssId(string $id): string
    {
        // Clean IDs are already normalized to [a-z0-9._-]. CSS.escape is not
        // available server-side, so escape the only CSS-special punctuation.
        return str_replace(['.', ':'], ['\\.', '\\:'], $id);
    }
}
