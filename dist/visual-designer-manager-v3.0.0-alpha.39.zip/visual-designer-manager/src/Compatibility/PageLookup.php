<?php

declare(strict_types=1);

/**
 * get_page_by_path() also searches attachments, so a page lookup could return an
 * image with the same slug (e.g. an import then turned that image into a page).
 * This wrapper only ever returns a real page.
 */
if (!function_exists('vdm_page_by_path')) {
    function vdm_page_by_path($path): ?\WP_Post
    {
        $post = get_page_by_path((string) $path, OBJECT, 'page');
        return $post instanceof \WP_Post && $post->post_type === 'page' ? $post : null;
    }
}
