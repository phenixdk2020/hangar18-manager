<?php

declare(strict_types=1);

/**
 * Hidden admin routes (registered with an empty parent) have no menu title, and
 * wp-admin/admin-header.php then passes null to strip_tags(). Provide the title.
 */
add_action('current_screen', static function (): void {
    global $title, $plugin_page;
    $hidden = [
        'vdm-data' => 'Data (intern)',
        'vdm-conversion' => 'Konvertering (intern)',
        'vdm-transfer' => 'Import / recovery',
    ];
    if (empty($title) && is_string($plugin_page) && isset($hidden[$plugin_page])) {
        $title = $hidden[$plugin_page];
    }
});
