<?php

declare(strict_types=1);

namespace VisualDesignerManager\Update;

final class GitHubUpdater
{
    private const MANIFEST_URL = 'https://raw.githubusercontent.com/phenixdk2020/hangar18-manager/v3-clean-refactor/v3-update.json';
    private const CACHE_KEY = 'h18_clean_github_update_manifest_v1';
    private const CHECK_ACTION = 'h18_clean_check_update';
    private const CHECK_NONCE = 'h18_clean_check_update';
    private const INSTALL_ACTION = 'h18_clean_install_update';
    private const INSTALL_NONCE = 'h18_clean_install_update';
    private const SAVE_ACTION = 'h18_clean_save';
    private const SAVE_NONCE = 'h18_clean_save';
    private const SLUG = 'visual-designer-manager';
    private const PLUGIN_FILE = 'visual-designer-manager/visual-designer-manager.php';
    private const BACKUP_OPTION = 'h18_clean_program_backups_v1';
    private const LAST_BACKUP_TRANSIENT_PREFIX = 'h18_clean_last_program_backup_';
    private const MAX_BACKUPS = 12;

    private static bool $backupCreatedThisRequest = false;

    public static function register(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [self::class, 'injectUpdate']);
        add_filter('plugins_api', [self::class, 'pluginInfo'], 20, 3);
        add_filter('upgrader_pre_download', [self::class, 'verifyDownload'], 20, 4);
        add_filter('upgrader_pre_install', [self::class, 'backupBeforeInstall'], 20, 2);
        add_action('admin_post_' . self::CHECK_ACTION, [self::class, 'manualCheck']);
        add_action('admin_post_' . self::INSTALL_ACTION, [self::class, 'installNow']);
        add_action('admin_post_' . self::SAVE_ACTION, [self::class, 'requireChangeNote'], 1);
        add_action('upgrader_process_complete', [self::class, 'clearCache'], 10, 2);
        add_action('admin_notices', [self::class, 'adminNotice']);
    }

    public static function injectUpdate(mixed $transient): mixed
    {
        if (!is_object($transient) || !isset($transient->checked) || !is_array($transient->checked)) {
            return $transient;
        }

        $manifest = self::manifest();
        if ($manifest === null) {
            return $transient;
        }

        $item = self::updateObject($manifest);
        if (version_compare((string) $manifest['version'], VDM_VERSION, '>')) {
            $transient->response[self::PLUGIN_FILE] = $item;
            if (isset($transient->no_update[self::PLUGIN_FILE])) {
                unset($transient->no_update[self::PLUGIN_FILE]);
            }
        } else {
            $transient->no_update[self::PLUGIN_FILE] = $item;
            if (isset($transient->response[self::PLUGIN_FILE])) {
                unset($transient->response[self::PLUGIN_FILE]);
            }
        }

        return $transient;
    }

    public static function pluginInfo(mixed $result, string $action, mixed $args): mixed
    {
        if ($action !== 'plugin_information' || !is_object($args) || (string) ($args->slug ?? '') !== self::SLUG) {
            return $result;
        }

        $manifest = self::manifest();
        if ($manifest === null) {
            return $result;
        }

        $info = new \stdClass();
        $info->name = (string) ($manifest['name'] ?? 'Visual Designer Manager');
        $info->slug = self::SLUG;
        $info->version = (string) $manifest['version'];
        $info->author = '<a href="https://github.com/phenixdk2020/hangar18-manager">Visual Designer Manager</a>';
        $info->homepage = (string) ($manifest['homepage'] ?? 'https://github.com/phenixdk2020/hangar18-manager');
        $info->requires = (string) ($manifest['requires'] ?? '6.4');
        $info->requires_php = (string) ($manifest['requires_php'] ?? '8.0');
        $info->tested = (string) ($manifest['tested'] ?? '');
        $info->download_link = (string) $manifest['package'];
        $info->sections = is_array($manifest['sections'] ?? null) ? $manifest['sections'] : [
            'description' => 'Visual Designer Manager.',
            'changelog' => '',
        ];
        return $info;
    }

    public static function verifyDownload(mixed $reply, string $package, mixed $upgrader, array $hookExtra = []): mixed
    {
        if ($reply !== false) {
            return $reply;
        }
        if (($hookExtra['plugin'] ?? '') !== self::PLUGIN_FILE) {
            return false;
        }

        $manifest = self::manifest(true);
        if ($manifest === null || $package !== (string) $manifest['package']) {
            return false;
        }

        $expected = strtolower((string) ($manifest['sha256'] ?? ''));
        if (!preg_match('/^[a-f0-9]{64}$/', $expected)) {
            return new \WP_Error('h18_clean_update_hash_missing', 'GitHub-manifestet mangler en gyldig SHA-256 for update-pakken.');
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url($package, 300, false);
        if (is_wp_error($file)) {
            return $file;
        }
        $actual = strtolower((string) hash_file('sha256', $file));
        if (!hash_equals($expected, $actual)) {
            @unlink($file);
            return new \WP_Error('h18_clean_update_hash_mismatch', 'Visual Designer Manager-updatepakken blev afvist: SHA-256 matcher ikke GitHub-manifestet.');
        }
        return $file;
    }

    public static function backupBeforeInstall(mixed $response, array $hookExtra = []): mixed
    {
        if (is_wp_error($response) || self::$backupCreatedThisRequest) {
            return $response;
        }
        $plugin = (string) ($hookExtra['plugin'] ?? '');
        $plugins = is_array($hookExtra['plugins'] ?? null) ? $hookExtra['plugins'] : [];
        if ($plugin !== self::PLUGIN_FILE && !in_array(self::PLUGIN_FILE, $plugins, true)) {
            return $response;
        }

        $manifest = self::manifest();
        $targetVersion = is_array($manifest) ? (string) ($manifest['version'] ?? '') : '';
        $backup = self::createProgramBackup($targetVersion);
        if (is_wp_error($backup)) {
            return new \WP_Error(
                'h18_clean_program_backup_failed',
                'Visual Designer Manager-opdateringen blev stoppet, fordi programbackup ikke kunne oprettes: ' . $backup->get_error_message()
            );
        }

        self::$backupCreatedThisRequest = true;
        $userId = get_current_user_id();
        if ($userId > 0) {
            set_transient(self::LAST_BACKUP_TRANSIENT_PREFIX . $userId, $backup, HOUR_IN_SECONDS);
        }
        return $response;
    }

    public static function requireChangeNote(): void
    {
        if (!current_user_can('edit_pages')) {
            return;
        }
        $nonce = isset($_POST['_wpnonce']) ? (string) wp_unslash($_POST['_wpnonce']) : '';
        if ($nonce === '' || !wp_verify_nonce($nonce, self::SAVE_NONCE)) {
            return;
        }
        $note = isset($_POST['change_note']) ? trim(sanitize_text_field((string) wp_unslash($_POST['change_note']))) : '';
        if ($note !== '') {
            return;
        }

        $postId = absint($_POST['post_id'] ?? 0);
        if ($postId > 0 && self::isNoopDesignerSave($postId)) {
            return;
        }
        $url = admin_url('admin.php?page=vdm-editor');
        if ($postId > 0) {
            $url = add_query_arg('post', $postId, $url);
        }
        $url = add_query_arg([
            'h18_clean_status' => 'error',
            'h18_clean_message' => 'Skriv en kort ændringsbeskrivelse før siden gemmes som en ny version.',
        ], $url);
        wp_safe_redirect($url);
        exit;
    }


    private static function isNoopDesignerSave(int $postId): bool
    {
        try {
            $json = (string) wp_unslash($_POST['model_json'] ?? '');
            $decoded = json_decode($json, true);
            if (!is_array($decoded)) { return false; }
            $normalized = \VisualDesignerManager\Model\LayoutModel::normalize($decoded);
            $currentVersion = max(0, (int) get_post_meta($postId, \VisualDesignerManager\Model\LayoutModel::VERSION_META, true));
            if ($currentVersion <= 0) { return false; }
            $sameModel = hash_equals(
                \VisualDesignerManager\Model\LayoutModel::structuralDigest(\VisualDesignerManager\Model\LayoutModel::get($postId)),
                \VisualDesignerManager\Model\LayoutModel::structuralDigest($normalized)
            );
            \VisualDesignerManager\Model\TemplateLayoutModel::ensureMigrated();
            $headerChoice = sanitize_key((string) wp_unslash($_POST['header_template_choice'] ?? 'auto')) ?: 'auto';
            $footerChoice = sanitize_key((string) wp_unslash($_POST['footer_template_choice'] ?? 'auto')) ?: 'auto';
            $sameShell = \VisualDesignerManager\Model\TemplateLayoutModel::pageChoice($postId, 'header') === $headerChoice
                && \VisualDesignerManager\Model\TemplateLayoutModel::pageChoice($postId, 'footer') === $footerChoice;
            $statusAction = sanitize_key((string) wp_unslash($_POST['post_status_action'] ?? ''));
            $statusChanged = in_array($statusAction, ['publish', 'draft'], true) && $statusAction !== (string) get_post_status($postId);
            return $sameModel && $sameShell && !$statusChanged;
        } catch (\Throwable $error) {
            return false;
        }
    }

    public static function manualCheck(): void
    {
        if (!current_user_can('update_plugins')) {
            wp_die(esc_html__('Ingen adgang til plugin-opdateringer.', 'visual-designer-manager'));
        }
        check_admin_referer(self::CHECK_NONCE);

        self::clearCache();
        delete_site_transient('update_plugins');
        wp_clean_plugins_cache(true);
        require_once ABSPATH . 'wp-admin/includes/update.php';
        wp_update_plugins();

        $manifest = self::manifest(true);
        $status = 'error';
        $version = '';
        if ($manifest !== null) {
            $version = (string) $manifest['version'];
            $status = version_compare($version, VDM_VERSION, '>') ? 'available' : 'current';
        }

        self::redirectToUpdates([
            'h18_clean_update_check' => $status,
            'h18_clean_update_version' => $version,
        ]);
    }

    public static function checkButtonHtml(): string
    {
        if (!current_user_can('update_plugins')) {
            return '';
        }
        return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="h18-clean-update-check">'
            . '<input type="hidden" name="action" value="' . esc_attr(self::CHECK_ACTION) . '">'
            . '<input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce(self::CHECK_NONCE)) . '">'
            . '<button type="submit" class="button">↻ Tjek GitHub-opdatering</button>'
            . '</form>';
    }

    /** @return array{ok:bool,current:string,latest:string,available:bool} */
    public static function status(bool $force = false): array
    {
        $manifest = self::manifest($force);
        if ($manifest === null) {
            return ['ok' => false, 'current' => VDM_VERSION, 'latest' => '', 'available' => false];
        }
        $latest = (string) $manifest['version'];
        return [
            'ok' => true,
            'current' => VDM_VERSION,
            'latest' => $latest,
            'available' => version_compare($latest, VDM_VERSION, '>'),
        ];
    }

    public static function installButtonHtml(): string
    {
        if (!current_user_can('update_plugins')) {
            return '';
        }
        $status = self::status();
        if (!$status['ok'] || !$status['available']) {
            return '';
        }

        $manifest = self::manifest();
        $changelog = '';
        if (is_array($manifest) && is_array($manifest['sections'] ?? null)) {
            $changelog = (string) ($manifest['sections']['changelog'] ?? '');
        }

        $html = '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="h18-clean-update-install">'
            . '<input type="hidden" name="action" value="' . esc_attr(self::INSTALL_ACTION) . '">'
            . '<input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce(self::INSTALL_NONCE)) . '">'
            . '<button type="submit" class="button button-primary" onclick="return confirm(\'Der tages automatisk programbackup før installationen. Installer Visual Designer Manager ' . esc_attr($status['latest']) . ' nu?\');">Opdater nu til ' . esc_html($status['latest']) . '</button>'
            . '</form>';
        $html .= '<div class="h18-clean-update-details">'
            . '<p><strong>Automatisk sikkerhed:</strong> Før WordPress udskifter pluginfilerne, gemmes både en ZIP-backup af den installerede version og et Designer-data-checkpoint. Opdateringen afbrydes, hvis checkpointet ikke kan oprettes.</p>';
        if ($changelog !== '') {
            $html .= '<details open><summary><strong>Ændringer i version ' . esc_html($status['latest']) . '</strong></summary><div class="h18-clean-update-changelog">' . wp_kses_post($changelog) . '</div></details>';
        }
        $html .= '</div>';
        return $html;
    }

    /** @return array<int,array<string,mixed>> */
    public static function programBackups(): array
    {
        $history = get_option(self::BACKUP_OPTION, []);
        if (!is_array($history)) {
            return [];
        }
        $rows = array_values(array_filter($history, static fn($row): bool => is_array($row) && (string) ($row['file'] ?? '') !== ''));
        return array_reverse($rows);
    }

    /** @return array<int,array{version:string,date:string,items:array<int,string>}> */
    public static function releaseHistory(): array
    {
        $path = VDM_DIR . 'release-history.json';
        if (!is_file($path)) {
            return [];
        }
        $decoded = json_decode((string) file_get_contents($path), true);
        if (!is_array($decoded)) {
            return [];
        }
        $sourceRows = isset($decoded['versions']) && is_array($decoded['versions']) ? $decoded['versions'] : $decoded;
        $rows = [];
        foreach ($sourceRows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $version = sanitize_text_field((string) ($row['version'] ?? ''));
            if (!preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $version)) {
                continue;
            }
            $items = [];
            foreach (is_array($row['items'] ?? null) ? $row['items'] : [] as $item) {
                $text = sanitize_text_field((string) $item);
                if ($text !== '') {
                    $items[] = $text;
                }
            }
            $rows[] = [
                'version' => $version,
                'date' => sanitize_text_field((string) ($row['date'] ?? '')),
                'items' => $items,
            ];
        }
        usort($rows, static fn(array $a, array $b): int => version_compare($b['version'], $a['version']));
        return $rows;
    }

    public static function installNow(): void
    {
        if (!current_user_can('update_plugins')) {
            wp_die(esc_html__('Ingen adgang til plugin-opdateringer.', 'visual-designer-manager'));
        }
        check_admin_referer(self::INSTALL_NONCE);

        $manifest = self::manifest(true);
        if ($manifest === null) {
            self::redirectToUpdates(['h18_clean_update_install' => 'error']);
        }
        $latest = (string) $manifest['version'];
        if (!version_compare($latest, VDM_VERSION, '>')) {
            self::redirectToUpdates(['h18_clean_update_install' => 'current']);
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $wasNetworkActive = is_multisite() && is_plugin_active_for_network(self::PLUGIN_FILE);
        $wasActive = $wasNetworkActive || is_plugin_active(self::PLUGIN_FILE);

        self::clearCache();
        delete_site_transient('update_plugins');
        wp_clean_plugins_cache(true);
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        wp_update_plugins();

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);
        $result = $upgrader->upgrade(self::PLUGIN_FILE, ['clear_update_cache' => true]);
        if (is_wp_error($result) || $result === false) {
            self::redirectToUpdates([
                'h18_clean_update_install' => 'error',
                'h18_clean_update_version' => $latest,
            ]);
        }

        // Never execute the freshly replaced plugin again inside this request.
        // Plugin_Upgrader may temporarily remove the active flag while replacing files.
        // Restore the pre-update activation state directly, then let the redirect start
        // a clean WordPress request that loads the new plugin normally.
        wp_clean_plugins_cache(true);
        $validation = validate_plugin(self::PLUGIN_FILE);
        if (is_wp_error($validation)) {
            wp_safe_redirect(add_query_arg([
                'h18_clean_update_install' => 'plugin_invalid',
                'h18_clean_update_version' => $latest,
            ], admin_url('plugins.php')));
            exit;
        }

        if ($wasNetworkActive) {
            $networkPlugins = get_site_option('active_sitewide_plugins', []);
            $networkPlugins = is_array($networkPlugins) ? $networkPlugins : [];
            if (!isset($networkPlugins[self::PLUGIN_FILE])) {
                $networkPlugins[self::PLUGIN_FILE] = time();
                update_site_option('active_sitewide_plugins', $networkPlugins);
            }
        } elseif ($wasActive) {
            $activePlugins = get_option('active_plugins', []);
            $activePlugins = is_array($activePlugins) ? array_values($activePlugins) : [];
            if (!in_array(self::PLUGIN_FILE, $activePlugins, true)) {
                $activePlugins[] = self::PLUGIN_FILE;
                sort($activePlugins, SORT_STRING);
                update_option('active_plugins', $activePlugins);
            }
        }

        wp_clean_plugins_cache(true);
        if ($wasActive) {
            $stillActive = $wasNetworkActive
                ? is_plugin_active_for_network(self::PLUGIN_FILE)
                : is_plugin_active(self::PLUGIN_FILE);
            if (!$stillActive) {
                wp_safe_redirect(add_query_arg([
                    'h18_clean_update_install' => 'activation_error',
                    'h18_clean_update_version' => $latest,
                ], admin_url('plugins.php')));
                exit;
            }
        }

        self::redirectToUpdates([
            'h18_clean_update_install' => 'success',
            'h18_clean_update_version' => $latest,
        ]);
    }

    public static function adminNotice(): void
    {
        if (!current_user_can('update_plugins')) {
            return;
        }

        $version = isset($_GET['h18_clean_update_version']) ? sanitize_text_field((string) wp_unslash($_GET['h18_clean_update_version'])) : '';
        $install = isset($_GET['h18_clean_update_install']) ? sanitize_key((string) wp_unslash($_GET['h18_clean_update_install'])) : '';
        if ($install === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p><strong>Visual Designer Manager blev opdateret til ' . esc_html($version !== '' ? $version : VDM_VERSION) . '.</strong></p></div>';
        } elseif ($install === 'error') {
            echo '<div class="notice notice-error is-dismissible"><p>Opdateringen kunne ikke installeres. Programbackupen og den eksisterende plugin-version er bevaret.</p></div>';
        } elseif ($install === 'current') {
            echo '<div class="notice notice-success is-dismissible"><p>Visual Designer Manager er allerede opdateret.</p></div>';
        } elseif ($install === 'plugin_invalid') {
            echo '<div class="notice notice-error is-dismissible"><p>Den installerede pluginpakke kunne ikke valideres efter opdateringen. Programbackupen er bevaret.</p></div>';
        } elseif ($install === 'activation_error') {
            echo '<div class="notice notice-error is-dismissible"><p>Pluginet kunne ikke bekræftes aktivt efter opdateringen. Programbackupen er bevaret.</p></div>';
        }

        $userId = get_current_user_id();
        if ($userId > 0) {
            $backup = get_transient(self::LAST_BACKUP_TRANSIENT_PREFIX . $userId);
            if (is_array($backup)) {
                delete_transient(self::LAST_BACKUP_TRANSIENT_PREFIX . $userId);
                $size = isset($backup['size']) ? size_format((int) $backup['size']) : '';
                echo '<div class="notice notice-info is-dismissible"><p><strong>Programbackup oprettet før opdatering:</strong> ' . esc_html((string) ($backup['file'] ?? 'backup'));
                if ($size !== '') {
                    echo ' · ' . esc_html($size);
                }
                echo ' · SHA-256 <code>' . esc_html(substr((string) ($backup['sha256'] ?? ''), 0, 16)) . '…</code></p></div>';
            }
        }

        $status = isset($_GET['h18_clean_update_check']) ? sanitize_key((string) wp_unslash($_GET['h18_clean_update_check'])) : '';
        if ($status === 'available' && $version !== '') {
            echo '<div class="notice notice-info is-dismissible"><p><strong>Visual Designer Manager ' . esc_html($version) . ' er tilgængelig.</strong> Ændringerne vises under <a href="' . esc_url(admin_url('admin.php?page=vdm-updates')) . '">Visual Designer Manager → Opdateringer</a>.</p></div>';
        } elseif ($status === 'current') {
            echo '<div class="notice notice-success is-dismissible"><p>Visual Designer Manager ' . esc_html(VDM_VERSION) . ' er den nyeste GitHub-version.</p></div>';
        } elseif ($status !== '') {
            echo '<div class="notice notice-error is-dismissible"><p>GitHub update-manifestet kunne ikke læses. Den installerede plugin-version er ikke ændret.</p></div>';
        }
    }

    public static function clearCache(mixed $upgrader = null, mixed $hookExtra = null): void
    {
        delete_site_transient(self::CACHE_KEY);
    }

    /** @param array<string,string> $args */
    private static function redirectToUpdates(array $args = []): void
    {
        $url = add_query_arg(array_merge(['page' => 'vdm-updates'], $args), admin_url('admin.php'));
        wp_safe_redirect($url);
        exit;
    }

    private static function manifest(bool $force = false): ?array
    {
        if (!$force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached) && self::validManifest($cached)) {
                return $cached;
            }
        }

        $response = wp_remote_get(self::MANIFEST_URL, [
            'timeout' => 12,
            'redirection' => 3,
            'headers' => [
                'Accept' => 'application/json',
                'User-Agent' => 'Visual-Designer-Manager-V3/' . VDM_VERSION,
            ],
        ]);
        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }

        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($decoded) || !self::validManifest($decoded)) {
            return null;
        }
        set_site_transient(self::CACHE_KEY, $decoded, 15 * MINUTE_IN_SECONDS);
        return $decoded;
    }

    private static function validManifest(array $manifest): bool
    {
        $version = (string) ($manifest['version'] ?? '');
        $package = (string) ($manifest['package'] ?? '');
        $sha256 = strtolower((string) ($manifest['sha256'] ?? ''));
        if ($version === '' || $package === '' || !preg_match('/^[a-f0-9]{64}$/', $sha256)) {
            return false;
        }
        return str_starts_with($package, 'https://raw.githubusercontent.com/phenixdk2020/hangar18-manager/');
    }

    /** @return array<string,mixed>|\WP_Error */
    private static function createProgramBackup(string $targetVersion): array|\WP_Error
    {
        $source = untrailingslashit(VDM_DIR);
        if (!is_dir($source)) {
            return new \WP_Error('h18_clean_backup_source_missing', 'Den installerede pluginmappe blev ikke fundet.');
        }

        $directory = self::backupDirectory();
        if (!is_dir($directory) && !wp_mkdir_p($directory)) {
            return new \WP_Error('h18_clean_backup_dir_failed', 'Backupmappen kunne ikke oprettes i wp-content.');
        }
        self::protectBackupDirectory($directory);

        $safeCurrent = preg_replace('/[^0-9A-Za-z._-]/', '-', VDM_VERSION) ?: 'unknown';
        $safeTarget = preg_replace('/[^0-9A-Za-z._-]/', '-', $targetVersion) ?: 'unknown';
        $filename = 'visual-designer-manager-v' . $safeCurrent . '-before-v' . $safeTarget . '-' . gmdate('Ymd-His') . '.zip';
        $path = trailingslashit($directory) . $filename;

        if (class_exists('ZipArchive')) {
            $zip = new \ZipArchive();
            $opened = $zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
            if ($opened !== true) {
                return new \WP_Error('h18_clean_backup_zip_open', 'ZIP-arkivet kunne ikke oprettes.');
            }
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($source, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($iterator as $fileInfo) {
                if (!$fileInfo instanceof \SplFileInfo || !$fileInfo->isFile() || $fileInfo->isLink()) {
                    continue;
                }
                $fullPath = $fileInfo->getPathname();
                $relative = ltrim(substr($fullPath, strlen($source)), '/\\');
                if ($relative === '') {
                    continue;
                }
                if (!$zip->addFile($fullPath, 'visual-designer-manager/' . str_replace('\\', '/', $relative))) {
                    $zip->close();
                    @unlink($path);
                    return new \WP_Error('h18_clean_backup_zip_add', 'En pluginfil kunne ikke tilføjes til programbackupen.');
                }
            }
            if (!$zip->close()) {
                @unlink($path);
                return new \WP_Error('h18_clean_backup_zip_close', 'ZIP-arkivet kunne ikke afsluttes.');
            }
        } else {
            require_once ABSPATH . WPINC . '/class-pclzip.php';
            $archive = new \PclZip($path);
            $result = $archive->create($source, PCLZIP_OPT_REMOVE_PATH, dirname($source));
            if ($result === 0) {
                @unlink($path);
                return new \WP_Error('h18_clean_backup_pclzip', 'PclZip kunne ikke oprette programbackupen: ' . $archive->errorInfo(true));
            }
        }

        if (!is_file($path) || (int) filesize($path) <= 0) {
            @unlink($path);
            return new \WP_Error('h18_clean_backup_empty', 'Programbackupen blev tom eller mangler efter oprettelsen.');
        }

        $sha256 = strtolower((string) hash_file('sha256', $path));
        if (!preg_match('/^[a-f0-9]{64}$/', $sha256)) {
            @unlink($path);
            return new \WP_Error('h18_clean_backup_hash', 'Programbackupens SHA-256 kunne ikke beregnes.');
        }

        $checkpoint = self::createDesignerCheckpoint($directory, pathinfo($filename, PATHINFO_FILENAME), $targetVersion);
        if (is_wp_error($checkpoint)) {
            @unlink($path);
            return $checkpoint;
        }

        $entry = [
            'id' => substr(hash('sha256', $filename . '|' . $sha256), 0, 20),
            'file' => $filename,
            'version' => VDM_VERSION,
            'targetVersion' => $targetVersion,
            'createdUtc' => gmdate('c'),
            'sha256' => $sha256,
            'size' => (int) filesize($path),
            'dataFile' => (string) ($checkpoint['file'] ?? ''),
            'dataSha256' => (string) ($checkpoint['sha256'] ?? ''),
            'dataSize' => (int) ($checkpoint['size'] ?? 0),
        ];

        $history = get_option(self::BACKUP_OPTION, []);
        $history = is_array($history) ? array_values(array_filter($history, 'is_array')) : [];
        $history[] = $entry;
        while (count($history) > self::MAX_BACKUPS) {
            $old = array_shift($history);
            if (is_array($old)) {
                $oldFile = basename((string) ($old['file'] ?? ''));
                if ($oldFile !== '') {
                    @unlink(trailingslashit($directory) . $oldFile);
                }
                $oldDataFile = basename((string) ($old['dataFile'] ?? ''));
                if ($oldDataFile !== '') {
                    @unlink(trailingslashit($directory) . $oldDataFile);
                }
            }
        }
        update_option(self::BACKUP_OPTION, $history, false);
        return $entry;
    }

    /** @return array{file:string,sha256:string,size:int}|\WP_Error */
    private static function createDesignerCheckpoint(string $directory, string $baseName, string $targetVersion): array|\WP_Error
    {
        try {
            \VisualDesignerManager\Model\TemplateLayoutModel::ensureMigrated();
            $payload = [
                'product' => 'Visual Designer Manager update checkpoint',
                'schemaVersion' => \VisualDesignerManager\Model\LayoutModel::SCHEMA,
                'currentVersion' => VDM_VERSION,
                'targetVersion' => $targetVersion,
                'generatedUtc' => gmdate('c'),
                'pages' => [],
                'templates' => [],
            ];

            $pages = get_posts([
                'post_type' => 'page',
                'post_status' => 'any',
                'numberposts' => -1,
                'orderby' => 'ID',
                'order' => 'ASC',
            ]);
            foreach ($pages as $page) {
                if (!$page instanceof \WP_Post) {
                    continue;
                }
                $postId = (int) $page->ID;
                $headerChoice = \VisualDesignerManager\Model\TemplateLayoutModel::pageChoice($postId, 'header');
                $footerChoice = \VisualDesignerManager\Model\TemplateLayoutModel::pageChoice($postId, 'footer');
                $hasLayout = metadata_exists('post', $postId, \VisualDesignerManager\Model\LayoutModel::META)
                    || (int) get_post_meta($postId, \VisualDesignerManager\Model\LayoutModel::VERSION_META, true) > 0;
                if (!$hasLayout && $headerChoice === 'auto' && $footerChoice === 'auto') {
                    continue;
                }
                $payload['pages'][] = [
                    'postId' => $postId,
                    'title' => (string) $page->post_title,
                    'slug' => (string) $page->post_name,
                    'status' => (string) $page->post_status,
                    'version' => (int) get_post_meta($postId, \VisualDesignerManager\Model\LayoutModel::VERSION_META, true),
                    'model' => \VisualDesignerManager\Model\LayoutModel::get($postId),
                    'history' => \VisualDesignerManager\Model\LayoutModel::history($postId),
                    'headerChoice' => $headerChoice,
                    'footerChoice' => $footerChoice,
                ];
            }

            foreach (['header', 'footer'] as $type) {
                foreach (\VisualDesignerManager\Model\TemplateLayoutModel::all($type) as $row) {
                    $id = (string) ($row['id'] ?? '');
                    if ($id === '') {
                        continue;
                    }
                    $payload['templates'][] = [
                        'id' => $id,
                        'type' => $type,
                        'name' => (string) ($row['name'] ?? ''),
                        'active' => !empty($row['active']),
                        'isDefault' => !empty($row['isDefault']),
                        'version' => \VisualDesignerManager\Model\TemplateLayoutModel::version($id),
                        'model' => \VisualDesignerManager\Model\TemplateLayoutModel::model($id),
                        'settings' => \VisualDesignerManager\Model\TemplateLayoutModel::settings($id),
                        'history' => \VisualDesignerManager\Model\TemplateLayoutModel::history($id),
                    ];
                }
            }

            $json = wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (!is_string($json)) {
                return new \WP_Error('h18_clean_checkpoint_json', 'Designer-data kunne ikke serialiseres til update-checkpoint.');
            }
            $filename = sanitize_file_name($baseName . '-designer-data.json');
            $path = trailingslashit($directory) . $filename;
            if (@file_put_contents($path, $json . "\n") === false || !is_file($path) || (int) filesize($path) <= 0) {
                @unlink($path);
                return new \WP_Error('h18_clean_checkpoint_write', 'Designer-data-checkpoint kunne ikke gemmes.');
            }
            $sha256 = strtolower((string) hash_file('sha256', $path));
            if (!preg_match('/^[a-f0-9]{64}$/', $sha256)) {
                @unlink($path);
                return new \WP_Error('h18_clean_checkpoint_hash', 'Designer-data-checkpointets SHA-256 kunne ikke beregnes.');
            }
            return ['file' => $filename, 'sha256' => $sha256, 'size' => (int) filesize($path)];
        } catch (\Throwable $error) {
            return new \WP_Error('h18_clean_checkpoint_exception', 'Designer-data-checkpoint fejlede: ' . $error->getMessage());
        }
    }

    private static function backupDirectory(): string
    {
        $secret = substr(hash_hmac('sha256', 'hangar18-clean-program-backups', wp_salt('auth')), 0, 16);
        return trailingslashit(WP_CONTENT_DIR) . 'h18-clean-program-backups-' . $secret;
    }

    private static function protectBackupDirectory(string $directory): void
    {
        $index = trailingslashit($directory) . 'index.php';
        if (!file_exists($index)) {
            @file_put_contents($index, "<?php\nhttp_response_code(404);\nexit;\n");
        }
        $htaccess = trailingslashit($directory) . '.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Require all denied\nDeny from all\n");
        }
    }

    private static function updateObject(array $manifest): \stdClass
    {
        $item = new \stdClass();
        $item->id = 'github.com/phenixdk2020/hangar18-manager';
        $item->slug = self::SLUG;
        $item->plugin = self::PLUGIN_FILE;
        $item->new_version = (string) $manifest['version'];
        $item->url = (string) ($manifest['homepage'] ?? 'https://github.com/phenixdk2020/hangar18-manager');
        $item->package = (string) $manifest['package'];
        $item->tested = (string) ($manifest['tested'] ?? '');
        $item->requires_php = (string) ($manifest['requires_php'] ?? '8.0');
        $item->requires = (string) ($manifest['requires'] ?? '6.4');
        return $item;
    }
}
