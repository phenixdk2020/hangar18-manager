(function () {
    'use strict';

    var BREAKPOINT = 782;
    var REPAIR_CLASS = 'h18-vdm-mobile-flow-repair';
    var ROOT_SELECTOR = '.h18-vd-live-shell-page .h18-clean-front-surface';
    var PARENT_SELECTOR = ROOT_SELECTOR + ',.h18-vd-live-shell-page .h18-clean-front-section,.h18-vd-live-shell-page .h18-clean-front-container';

    function directNodes(parent) {
        return Array.prototype.filter.call(parent.children || [], function (child) {
            return child && child.classList && child.classList.contains('h18-clean-front-node');
        });
    }

    function depth(element) {
        var value = 0;
        for (var node = element; node && node.parentElement; node = node.parentElement) { value += 1; }
        return value;
    }

    function isSpacer(element) {
        return !!(element && element.classList && element.classList.contains('h18-clean-front-spacer'));
    }

    function isAbsolute(element) {
        try { return window.getComputedStyle(element).position === 'absolute'; }
        catch (error) { return false; }
    }

    function horizontalOverflow(parentRect, childRect) {
        return childRect.left < parentRect.left - 2 || childRect.right > parentRect.right + 2;
    }

    function intrinsicOverflow(element) {
        return element.scrollWidth > element.clientWidth + 2 || element.scrollHeight > element.clientHeight + 2;
    }

    function overlaps(a, b) {
        var x = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        var y = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return x > 4 && y > 4;
    }

    function needsRepair(parent) {
        var children = directNodes(parent);
        if (!children.length) { return false; }
        var parentRect = parent.getBoundingClientRect();
        var normal = [];
        var i;
        for (i = 0; i < children.length; i += 1) {
            var child = children[i];
            var rect = child.getBoundingClientRect();
            if (horizontalOverflow(parentRect, rect) || intrinsicOverflow(child)) { return true; }
            if (!isAbsolute(child)) { normal.push({ element: child, rect: rect }); }
        }
        normal.sort(function (a, b) { return a.rect.top - b.rect.top || a.rect.left - b.rect.left; });
        for (i = 1; i < normal.length; i += 1) {
            if (overlaps(normal[i - 1].rect, normal[i].rect)) { return true; }
        }
        if (parent.matches(ROOT_SELECTOR) && normal.length > 1) {
            for (i = 1; i < normal.length; i += 1) {
                var gap = normal[i].rect.top - normal[i - 1].rect.bottom;
                if (gap > 160 && !isSpacer(normal[i - 1].element) && !isSpacer(normal[i].element)) { return true; }
            }
        }
        return false;
    }

    function runRepair() {
        if (!window.matchMedia || !window.matchMedia('(max-width:' + BREAKPOINT + 'px)').matches) {
            document.querySelectorAll('.' + REPAIR_CLASS).forEach(function (node) { node.classList.remove(REPAIR_CLASS); });
            return;
        }
        var parents = Array.prototype.slice.call(document.querySelectorAll(PARENT_SELECTOR));
        parents.sort(function (a, b) { return depth(b) - depth(a); });
        for (var pass = 0; pass < 3; pass += 1) {
            var changed = false;
            parents.forEach(function (parent) {
                if (!parent.classList.contains(REPAIR_CLASS) && needsRepair(parent)) {
                    parent.classList.add(REPAIR_CLASS);
                    changed = true;
                }
            });
            if (!changed) { break; }
        }
    }

    var pending = 0;
    function schedule() {
        if (pending) { window.cancelAnimationFrame(pending); }
        pending = window.requestAnimationFrame(function () { pending = 0; runRepair(); });
    }

    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', schedule, { once: true }); }
    else { schedule(); }
    window.addEventListener('load', schedule, { once: true });
    window.addEventListener('resize', schedule, { passive: true });
    if (document.fonts && document.fonts.ready) { document.fonts.ready.then(schedule); }
}());
